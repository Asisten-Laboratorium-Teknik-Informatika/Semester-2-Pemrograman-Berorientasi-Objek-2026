package detail;

public class DetailResep {
    private int idDetailResep;
    private int idResep;
    private int idObat;
    private int jumlahObat;
    private String dosis;

    public DetailResep(int idDetailResep, int idResep, int idObat, int jumlahObat, String dosis) {
        this.idDetailResep = idDetailResep;
        this.idResep = idResep;
        this.idObat = idObat;
        this.jumlahObat = jumlahObat;
        this.dosis = dosis;
    }

    public int getIdDetailResep() {
        return idDetailResep;
    }

    public int getIdResep() {
        return idResep;
    }

    public int getIdObat() {
        return idObat;
    }

    public int getJumlahObat() {
        return jumlahObat;
    }

    public String getDosis() {
        return dosis;
    }

    public void setIdDetailResep(int idDetailResep) {
        this.idDetailResep = idDetailResep;
    }

    public void setIdResep(int idResep) {
        this.idResep = idResep;
    }

    public void setIdObat(int idObat) {
        this.idObat = idObat;
    }

    public void setJumlahObat(int jumlahObat) {
        this.jumlahObat = jumlahObat;
    }

    public void setDosis(String dosis) {
        this.dosis = dosis;
    }

}
