
import view.MenuUtama;

public class Main {
    public static void main(String[] args) {
        MenuUtama menuUtama = new MenuUtama();
        menuUtama.tampilMenuUtama();
    }

}
