package model;

public class Pasien {
    private int idPasien;
    private String nama;
    private String jenisKelamin;
    private String tanggalLahir;
    private String alamat;
    private String noHp;
    private String golonganDarah;

    public Pasien(int idPasien, String nama, String jenisKelamin, String tanggalLahir, String alamat, String noHp, String golonganDarah) {
        this.idPasien = idPasien;
        this.nama = nama;
        this.jenisKelamin = jenisKelamin;
        this.tanggalLahir = tanggalLahir;
        this.alamat = alamat;
        this.noHp = noHp;
        this.golonganDarah = golonganDarah;
    }

    public int getIdPasien() {
        return idPasien;
    }

    public String getNama() {
        return nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public String getNoHp() {
        return noHp;
    }

    public String getJenisKelamin() {
        return jenisKelamin;
    }

    public String getGolonganDarah() {
        return golonganDarah;
    }

    public String getTanggalLahir() {
        return tanggalLahir;
    }

    public void setIdPasien(int idPasien) {
        this.idPasien = idPasien;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public void setNoHp(String noHp) {
        this.noHp = noHp;
    }

    public void setJenisKelamin(String jenisKelamin) {
        this.jenisKelamin = jenisKelamin;
    }

    public void setGolonganDarah(String golonganDarah) {
        this.golonganDarah = golonganDarah;
    }

    public void setTanggalLahir(String tanggalLahir) {
        this.tanggalLahir = tanggalLahir;
    }

}
