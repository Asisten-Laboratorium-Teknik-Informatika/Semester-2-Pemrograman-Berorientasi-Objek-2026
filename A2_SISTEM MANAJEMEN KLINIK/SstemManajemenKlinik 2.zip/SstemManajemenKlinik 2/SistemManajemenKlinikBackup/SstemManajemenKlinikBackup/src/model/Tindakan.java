package model;

public class Tindakan {
    private String namaTindakan;
    private int idTindakan;
    private double biayaTindakan;

    public Tindakan(int idTindakan, String namaTindakan, double biayaTindakan) {
        this.idTindakan = idTindakan;
        this.namaTindakan = namaTindakan;
        this.biayaTindakan = biayaTindakan;
    }

    public String getNamaTindakan() {
        return namaTindakan;
    }

    public int getIdTindakan() {
        return idTindakan;
    }

    public double getBiayaTindakan() {
        return biayaTindakan;
    }

    public void setNamaTindakan(String namaTindakan) {
        this.namaTindakan = namaTindakan;
    }

    public void setIdTindakan(int idTindakan) {
        this.idTindakan = idTindakan;
    }

    public void setBiayaTindakan(double biayaTindakan) {
        this.biayaTindakan = biayaTindakan;
    }

}
