package model;

public class Poli {
    private String namaPoli;
    private String lokasiPoli;
    private int idPoli;

    public Poli(int idPoli, String lokasiPoli, String namaPoli) {
        this.idPoli = idPoli;
        this.lokasiPoli = lokasiPoli;
        this.namaPoli = namaPoli;
    }

    public String getNamaPoli() {
        return namaPoli;
    }

    public String getLokasiPoli() {
        return lokasiPoli;
    }

    public int getIdPoli() {
        return idPoli;
    }

    public void setNamaPoli(String namaPoli) {
        this.namaPoli = namaPoli;
    }

    public void setLokasiPoli(String lokasiPoli) {
        this.lokasiPoli = lokasiPoli;
    }

    public void setIdPoli(int idPoli) {
        this.idPoli = idPoli;
    }

}
