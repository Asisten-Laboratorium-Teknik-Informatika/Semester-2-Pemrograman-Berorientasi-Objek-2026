package crud;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import detail.DetailResep;

public class DetailResepM {

    public void tambahDetailResep(DetailResep detailResep) {
        String sql = "INSERT INTO detail_resep (id_resep, id_obat, jumlah_obat, dosis) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, detailResep.getIdResep());
            stmt.setInt(2, detailResep.getIdObat());
            stmt.setInt(3, detailResep.getJumlahObat());
            stmt.setString(4, detailResep.getDosis());
            stmt.executeUpdate();

            System.out.println("Data detail resep berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah detail resep: " + e.getMessage());
        }
    }

    public void tampilDetailResep() {
        String sql = "SELECT * FROM detail_resep";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID          : " + rs.getInt("id_detail_resep"));
                System.out.println("ID Resep    : " + rs.getInt("id_resep"));
                System.out.println("ID Obat     : " + rs.getInt("id_obat"));
                System.out.println("Jumlah      : " + rs.getInt("jumlah_obat"));
                System.out.println("Dosis       : " + rs.getString("dosis"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data detail resep.");

        } catch (Exception e) {
            System.out.println("Gagal tampil detail resep: " + e.getMessage());
        }
    }

    public void updateDetailResep(int idDetailResep, int idResep, int idObat, int jumlah, String dosis) {
        String sql = "UPDATE detail_resep SET id_resep=?, id_obat=?, jumlah_obat=?, dosis=? WHERE id_detail_resep=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idResep);
            stmt.setInt(2, idObat);
            stmt.setInt(3, jumlah);
            stmt.setString(4, dosis);
            stmt.setInt(5, idDetailResep);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data detail resep berhasil diupdate");
            else System.out.println("Data detail resep tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update detail resep: " + e.getMessage());
        }
    }

    public void hapusDetailResep(int idDetailResep) {
        String sql = "DELETE FROM detail_resep WHERE id_detail_resep=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idDetailResep);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data detail resep berhasil dihapus");
            else System.out.println("Data detail resep tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus detail resep: " + e.getMessage());
        }
    }
}