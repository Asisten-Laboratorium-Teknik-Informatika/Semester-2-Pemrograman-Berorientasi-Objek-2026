package crud;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import transaksi.RawatInap;

public class RawatInapM {

    public void tambahRawatInap(RawatInap rawatInap) {
        String sql = "INSERT INTO rawat_inap (id_pendaftaran, nomor_kamar, tanggal_masuk, tanggal_keluar) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, rawatInap.getIdPendaftaran());
            stmt.setString(2, rawatInap.getNomorKamar());
            stmt.setDate(3, Date.valueOf(rawatInap.getTanggalMasuk()));
            stmt.setDate(4, rawatInap.getTanggalKeluar() != null ? Date.valueOf(rawatInap.getTanggalKeluar()) : null);
            stmt.executeUpdate();

            System.out.println("Data rawat inap berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah rawat inap: " + e.getMessage());
        }
    }

    public void tampilRawatInap() {
        String sql = "SELECT * FROM rawat_inap";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID             : " + rs.getInt("id_rawat_inap"));
                System.out.println("ID Pendaftaran : " + rs.getInt("id_pendaftaran"));
                System.out.println("Nomor Kamar    : " + rs.getString("nomor_kamar"));
                System.out.println("Tanggal Masuk  : " + rs.getDate("tanggal_masuk"));
                System.out.println("Tanggal Keluar : " + rs.getDate("tanggal_keluar"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data rawat inap.");

        } catch (Exception e) {
            System.out.println("Gagal tampil rawat inap: " + e.getMessage());
        }
    }

    public void updateRawatInap(int idRawatInap, int idPendaftaran, String nomorKamar, String tanggalMasuk, String tanggalKeluar) {
        String sql = "UPDATE rawat_inap SET id_pendaftaran=?, nomor_kamar=?, tanggal_masuk=?, tanggal_keluar=? WHERE id_rawat_inap=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPendaftaran);
            stmt.setString(2, nomorKamar);
            stmt.setDate(3, Date.valueOf(tanggalMasuk));
            stmt.setDate(4, tanggalKeluar != null ? Date.valueOf(tanggalKeluar) : null);
            stmt.setInt(5, idRawatInap);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data rawat inap berhasil diupdate");
            else System.out.println("Data rawat inap tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update rawat inap: " + e.getMessage());
        }
    }

    public void hapusRawatInap(int idRawatInap) {
        String sql = "DELETE FROM rawat_inap WHERE id_rawat_inap=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idRawatInap);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data rawat inap berhasil dihapus");
            else System.out.println("Data rawat inap tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus rawat inap: " + e.getMessage());
        }
    }
}