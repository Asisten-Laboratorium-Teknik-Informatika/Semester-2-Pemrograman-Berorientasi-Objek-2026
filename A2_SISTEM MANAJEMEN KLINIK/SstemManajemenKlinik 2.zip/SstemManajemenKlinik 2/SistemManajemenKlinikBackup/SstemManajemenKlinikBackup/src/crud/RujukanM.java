package crud;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import transaksi.Rujukan;

public class RujukanM {

    public void tambahRujukan(Rujukan rujukan) {
        String sql = "INSERT INTO rujukan (id_pasien, alasan_rujukan, tujuan_rujukan, tanggal_rujukan) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, rujukan.getIdPasien());
            stmt.setString(2, rujukan.getAlasanRujukan());
            stmt.setString(3, rujukan.getTujuanRujukan());
            stmt.setDate(4, Date.valueOf(rujukan.getTanggalRujukan()));
            stmt.executeUpdate();

            System.out.println("Data rujukan berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah rujukan: " + e.getMessage());
        }
    }

    public void tampilRujukan() {
        String sql = "SELECT * FROM rujukan";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID        : " + rs.getInt("id_rujukan"));
                System.out.println("ID Pasien : " + rs.getInt("id_pasien"));
                System.out.println("Alasan    : " + rs.getString("alasan_rujukan"));
                System.out.println("Tujuan    : " + rs.getString("tujuan_rujukan"));
                System.out.println("Tanggal   : " + rs.getDate("tanggal_rujukan"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data rujukan.");

        } catch (Exception e) {
            System.out.println("Gagal tampil rujukan: " + e.getMessage());
        }
    }

    public void updateRujukan(int idRujukan, int idPasien, String alasanRujukan, String tujuanRujukan, String tanggalRujukan) {
        String sql = "UPDATE rujukan SET id_pasien=?, alasan_rujukan=?, tujuan_rujukan=?, tanggal_rujukan=? WHERE id_rujukan=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPasien);
            stmt.setString(2, alasanRujukan);
            stmt.setString(3, tujuanRujukan);
            stmt.setDate(4, Date.valueOf(tanggalRujukan));
            stmt.setInt(5, idRujukan);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data rujukan berhasil diupdate");
            else System.out.println("Data rujukan tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update rujukan: " + e.getMessage());
        }
    }

    public void hapusRujukan(int idRujukan) {
        String sql = "DELETE FROM rujukan WHERE id_rujukan=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idRujukan);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data rujukan berhasil dihapus");
            else System.out.println("Data rujukan tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus rujukan: " + e.getMessage());
        }
    }
}