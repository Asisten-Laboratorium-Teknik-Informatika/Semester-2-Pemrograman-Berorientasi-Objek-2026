package crud;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import model.Pegawai;

public class PegawaiM {

    public void tambahPegawai(Pegawai pegawai) {
        String sql = "INSERT INTO pegawai (nama_pegawai, alamat, no_hp, email, username, password, id_role) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, pegawai.getNamaPegawai());
            stmt.setString(2, pegawai.getAlamat());
            stmt.setString(3, pegawai.getNoHp());
            stmt.setString(4, pegawai.getEmail());
            stmt.setString(5, pegawai.getUsername());
            stmt.setString(6, pegawai.getPassword());
            stmt.setInt(7, pegawai.getIdRole());
            stmt.executeUpdate();

            System.out.println("Data pegawai berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah pegawai: " + e.getMessage());
        }
    }

    public void tampilPegawai() {
        String sql = "SELECT * FROM pegawai";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID       : " + rs.getInt("id_pegawai"));
                System.out.println("Nama     : " + rs.getString("nama_pegawai"));
                System.out.println("Alamat   : " + rs.getString("alamat"));
                System.out.println("No HP    : " + rs.getString("no_hp"));
                System.out.println("Email    : " + rs.getString("email"));
                System.out.println("Username : " + rs.getString("username"));
                System.out.println("Password : " + rs.getString("password"));
                System.out.println("ID Role  : " + rs.getInt("id_role"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data pegawai.");

        } catch (Exception e) {
            System.out.println("Gagal tampil pegawai: " + e.getMessage());
        }
    }

    public void updatePegawai(int idPegawai, String namaPegawai, String alamat, String noHp, String email, String username, String password, int idRole) {
        String sql = "UPDATE pegawai SET nama_pegawai=?, alamat=?, no_hp=?, email=?, username=?, password=?, id_role=? WHERE id_pegawai=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, namaPegawai);
            stmt.setString(2, alamat);
            stmt.setString(3, noHp);
            stmt.setString(4, email);
            stmt.setString(5, username);
            stmt.setString(6, password);
            stmt.setInt(7, idRole);
            stmt.setInt(8, idPegawai);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data pegawai berhasil diupdate");
            else System.out.println("Data pegawai tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update pegawai: " + e.getMessage());
        }
    }

    public void hapusPegawai(int idPegawai) {
        String sql = "DELETE FROM pegawai WHERE id_pegawai=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPegawai);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data pegawai berhasil dihapus");
            else System.out.println("Data pegawai tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus pegawai: " + e.getMessage());
        }
    }
}