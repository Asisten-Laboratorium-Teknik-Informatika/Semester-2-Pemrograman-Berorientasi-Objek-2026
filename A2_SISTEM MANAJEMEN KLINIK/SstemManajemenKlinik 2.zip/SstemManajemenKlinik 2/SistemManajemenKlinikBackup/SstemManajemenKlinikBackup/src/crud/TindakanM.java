package crud;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import model.Tindakan;

public class TindakanM {

    public void tambahTindakan(Tindakan tindakan) {
        String sql = "INSERT INTO tindakan (nama_tindakan, biaya_tindakan) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, tindakan.getNamaTindakan());
            stmt.setDouble(2, tindakan.getBiayaTindakan());
            stmt.executeUpdate();

            System.out.println("Data tindakan berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah tindakan: " + e.getMessage());
        }
    }

    public void tampilTindakan() {
        String sql = "SELECT * FROM tindakan";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID    : " + rs.getInt("id_tindakan"));
                System.out.println("Nama  : " + rs.getString("nama_tindakan"));
                System.out.println("Harga : " + rs.getDouble("biaya_tindakan"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data tindakan.");

        } catch (Exception e) {
            System.out.println("Gagal tampil tindakan: " + e.getMessage());
        }
    }

    public void updateTindakan(int idTindakan, String namaTindakan, double biayaTindakan) {
        String sql = "UPDATE tindakan SET nama_tindakan=?, biaya_tindakan=? WHERE id_tindakan=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, namaTindakan);
            stmt.setDouble(2, biayaTindakan);
            stmt.setInt(3, idTindakan);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data tindakan berhasil diupdate");
            else System.out.println("Data tindakan tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update tindakan: " + e.getMessage());
        }
    }

    public void hapusTindakan(int idTindakan) {
        String sql = "DELETE FROM tindakan WHERE id_tindakan=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idTindakan);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data tindakan berhasil dihapus");
            else System.out.println("Data tindakan tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus tindakan: " + e.getMessage());
        }
    }
}