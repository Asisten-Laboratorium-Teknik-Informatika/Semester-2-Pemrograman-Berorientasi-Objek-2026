package crud;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import model.Dokter;

public class DokterM {

    public void tambahDokter(Dokter dokter) {
        String sql = "INSERT INTO dokter (nama_dokter, spesialis, no_hp, id_poli) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, dokter.getNamaDokter());
            stmt.setString(2, dokter.getSpesialis());
            stmt.setString(3, dokter.getNoHp());
            stmt.setInt(4, dokter.getIdPoli());
            stmt.executeUpdate();

            System.out.println("Data dokter berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah dokter: " + e.getMessage());
        }
    }

    public void tampilDokter() {
        String sql = "SELECT * FROM dokter";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID        : " + rs.getInt("id_dokter"));
                System.out.println("Nama      : " + rs.getString("nama_dokter"));
                System.out.println("Spesialis : " + rs.getString("spesialis"));
                System.out.println("No HP     : " + rs.getString("no_hp"));
                System.out.println("ID Poli   : " + rs.getInt("id_poli"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data dokter.");

        } catch (Exception e) {
            System.out.println("Gagal tampil dokter: " + e.getMessage());
        }
    }

    public void updateDokter(int idDokter, String namaDokter, String spesialis, String noHp, int idPoli) {
        String sql = "UPDATE dokter SET nama_dokter=?, spesialis=?, no_hp=?, id_poli=? WHERE id_dokter=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, namaDokter);
            stmt.setString(2, spesialis);
            stmt.setString(3, noHp);
            stmt.setInt(4, idPoli);
            stmt.setInt(5, idDokter);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data dokter berhasil diupdate");
            else System.out.println("Data dokter tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update dokter: " + e.getMessage());
        }
    }

    public void hapusDokter(int idDokter) {
        String sql = "DELETE FROM dokter WHERE id_dokter=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idDokter);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data dokter berhasil dihapus");
            else System.out.println("Data dokter tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus dokter: " + e.getMessage());
        }
    }
}