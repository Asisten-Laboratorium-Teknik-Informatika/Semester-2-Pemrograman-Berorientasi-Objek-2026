package crud;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import model.Obat;

public class ObatM {

    public void tambahObat(Obat obat) {
        String sql = "INSERT INTO obat (nama_obat, jenis_obat, harga_obat, stok) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, obat.getNamaObat());
            stmt.setString(2, obat.getJenisObat());
            stmt.setDouble(3, obat.getHargaObat());
            stmt.setInt(4, obat.getStok());
            stmt.executeUpdate();

            System.out.println("Data obat berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah obat: " + e.getMessage());
        }
    }

    public void tampilObat() {
        String sql = "SELECT * FROM obat";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID    : " + rs.getInt("id_obat"));
                System.out.println("Nama  : " + rs.getString("nama_obat"));
                System.out.println("Jenis : " + rs.getString("jenis_obat"));
                System.out.println("Harga : " + rs.getDouble("harga_obat"));
                System.out.println("Stok  : " + rs.getInt("stok"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data obat.");

        } catch (Exception e) {
            System.out.println("Gagal tampil obat: " + e.getMessage());
        }
    }

    public void updateObat(int idObat, String nama, String jenisObat, double hargaObat, int stok) {
        String sql = "UPDATE obat SET nama_obat=?, jenis_obat=?, harga_obat=?, stok=? WHERE id_obat=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nama);
            stmt.setString(2, jenisObat);
            stmt.setDouble(3, hargaObat);
            stmt.setInt(4, stok);
            stmt.setInt(5, idObat);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data obat berhasil diupdate");
            else System.out.println("Data obat tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update obat: " + e.getMessage());
        }
    }

    public void hapusObat(int idObat) {
        String sql = "DELETE FROM obat WHERE id_obat=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idObat);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data obat berhasil dihapus");
            else System.out.println("Data obat tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus obat: " + e.getMessage());
        }
    }
}