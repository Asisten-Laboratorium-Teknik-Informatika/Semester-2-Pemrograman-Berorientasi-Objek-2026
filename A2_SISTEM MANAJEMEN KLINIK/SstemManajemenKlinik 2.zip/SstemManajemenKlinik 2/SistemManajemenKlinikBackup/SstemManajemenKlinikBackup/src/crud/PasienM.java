package crud;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import model.Pasien;

public class PasienM {

    public void tambahPasien(Pasien pasien) {
        String sql = "INSERT INTO pasien (nama, jenis_kelamin, tanggal_lahir, alamat, no_hp, golongan_darah) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, pasien.getNama());
            stmt.setString(2, pasien.getJenisKelamin());
            stmt.setDate(3, Date.valueOf(pasien.getTanggalLahir()));
            stmt.setString(4, pasien.getAlamat());
            stmt.setString(5, pasien.getNoHp());
            stmt.setString(6, pasien.getGolonganDarah());
            stmt.executeUpdate();

            System.out.println("Data pasien berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah pasien: " + e.getMessage());
        }
    }

    public void tampilPasien() {
        String sql = "SELECT * FROM pasien";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID             : " + rs.getInt("id_pasien"));
                System.out.println("Nama           : " + rs.getString("nama"));
                System.out.println("Jenis Kelamin  : " + rs.getString("jenis_kelamin"));
                System.out.println("Tanggal Lahir  : " + rs.getDate("tanggal_lahir"));
                System.out.println("Alamat         : " + rs.getString("alamat"));
                System.out.println("No HP          : " + rs.getString("no_hp"));
                System.out.println("Golongan Darah : " + rs.getString("golongan_darah"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data pasien.");

        } catch (Exception e) {
            System.out.println("Gagal tampil pasien: " + e.getMessage());
        }
    }

    public void updatePasien(int idPasien, String nama, String jenisKelamin, String tanggalLahir, String alamat, String noHp, String golonganDarah) {
        String sql = "UPDATE pasien SET nama=?, jenis_kelamin=?, tanggal_lahir=?, alamat=?, no_hp=?, golongan_darah=? WHERE id_pasien=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nama);
            stmt.setString(2, jenisKelamin);
            stmt.setDate(3, Date.valueOf(tanggalLahir));
            stmt.setString(4, alamat);
            stmt.setString(5, noHp);
            stmt.setString(6, golonganDarah);
            stmt.setInt(7, idPasien);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data pasien berhasil diupdate");
            else System.out.println("Data pasien tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update pasien: " + e.getMessage());
        }
    }

    public void hapusPasien(int idPasien) {
        String sql = "DELETE FROM pasien WHERE id_pasien=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPasien);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data pasien berhasil dihapus");
            else System.out.println("Data pasien tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus pasien: " + e.getMessage());
        }
    }
}