package crud;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import detail.DetailTindakan;

public class DetailTindakanM {

    public void tambahDetailTindakan(DetailTindakan detailTindakan) {
        String sql = "INSERT INTO detail_tindakan (id_pemeriksaan, id_tindakan, jumlah) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, detailTindakan.getIdPemeriksaan());
            stmt.setInt(2, detailTindakan.getIdTindakan());
            stmt.setInt(3, detailTindakan.getJumlah());
            stmt.executeUpdate();

            System.out.println("Data detail tindakan berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah detail tindakan: " + e.getMessage());
        }
    }

    public void tampilDetailTindakan() {
        String sql = "SELECT * FROM detail_tindakan";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID             : " + rs.getInt("id_detail_tindakan"));
                System.out.println("ID Pemeriksaan : " + rs.getInt("id_pemeriksaan"));
                System.out.println("ID Tindakan    : " + rs.getInt("id_tindakan"));
                System.out.println("Jumlah         : " + rs.getInt("jumlah"));
                System.out.println("Subtotal       : " + rs.getDouble("sub_total"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data detail tindakan.");

        } catch (Exception e) {
            System.out.println("Gagal tampil detail tindakan: " + e.getMessage());
        }
    }

    public void updateDetailTindakan(int idDetailTindakan, int idPemeriksaan, int idTindakan, int jumlah, double subTotal) {
        String sql = "UPDATE detail_tindakan SET id_pemeriksaan=?, id_tindakan=?, jumlah=? WHERE id_detail_tindakan=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPemeriksaan);
            stmt.setInt(2, idTindakan);
            stmt.setInt(3, jumlah);
            stmt.setInt(4, idDetailTindakan);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data detail tindakan berhasil diupdate");
            else System.out.println("Data detail tindakan tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update detail tindakan: " + e.getMessage());
        }
    }

    public void hapusDetailTindakan(int idDetailTindakan) {
        String sql = "DELETE FROM detail_tindakan WHERE id_detail_tindakan=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idDetailTindakan);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data detail tindakan berhasil dihapus");
            else System.out.println("Data detail tindakan tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus detail tindakan: " + e.getMessage());
        }
    }
}