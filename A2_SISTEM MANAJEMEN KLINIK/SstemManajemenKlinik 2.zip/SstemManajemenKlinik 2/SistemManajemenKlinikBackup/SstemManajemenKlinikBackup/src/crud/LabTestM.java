package crud;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import transaksi.LabTest;

public class LabTestM {

    public void tambahLabTest(LabTest labTest) {
        String sql = "INSERT INTO lab_test (id_pemeriksaan, jenis_test, hasil_test, tanggal_test) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, labTest.getIdPemeriksaan());
            stmt.setString(2, labTest.getJenisTest());
            stmt.setString(3, labTest.getHasilTest());
            stmt.setDate(4, Date.valueOf(labTest.getTanggalTest()));
            stmt.executeUpdate();

            System.out.println("Data lab test berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah lab test: " + e.getMessage());
        }
    }

    public void tampilLabTest() {
        String sql = "SELECT * FROM lab_test";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID             : " + rs.getInt("id_lab_test"));
                System.out.println("ID Pemeriksaan : " + rs.getInt("id_pemeriksaan"));
                System.out.println("Jenis Test     : " + rs.getString("jenis_test"));
                System.out.println("Hasil Test     : " + rs.getString("hasil_test"));
                System.out.println("Tanggal Test   : " + rs.getDate("tanggal_test"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data lab test.");

        } catch (Exception e) {
            System.out.println("Gagal tampil lab test: " + e.getMessage());
        }
    }

    public void updateLabTest(int idLabTest, int idPemeriksaan, String jenisTest, String hasilTest, String tanggalTest) {
        String sql = "UPDATE lab_test SET id_pemeriksaan=?, jenis_test=?, hasil_test=?, tanggal_test=? WHERE id_lab_test=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPemeriksaan);
            stmt.setString(2, jenisTest);
            stmt.setString(3, hasilTest);
            stmt.setDate(4, Date.valueOf(tanggalTest));
            stmt.setInt(5, idLabTest);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data lab test berhasil diupdate");
            else System.out.println("Data lab test tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update lab test: " + e.getMessage());
        }
    }

    public void hapusLabTest(int idLabTest) {
        String sql = "DELETE FROM lab_test WHERE id_lab_test=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idLabTest);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data lab test berhasil dihapus");
            else System.out.println("Data lab test tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus lab test: " + e.getMessage());
        }
    }
}