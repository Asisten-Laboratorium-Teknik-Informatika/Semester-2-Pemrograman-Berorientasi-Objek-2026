package crud;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import model.Poli;

public class PoliM {

    public void tambahPoli(Poli poli) {
        String sql = "INSERT INTO poli (nama_poli, lokasi_poli) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, poli.getNamaPoli());
            stmt.setString(2, poli.getLokasiPoli());
            stmt.executeUpdate();

            System.out.println("Data poli berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah poli: " + e.getMessage());
        }
    }

    public void tampilPoli() {
        String sql = "SELECT * FROM poli";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID     : " + rs.getInt("id_poli"));
                System.out.println("Nama   : " + rs.getString("nama_poli"));
                System.out.println("Lokasi : " + rs.getString("lokasi_poli"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data poli.");

        } catch (Exception e) {
            System.out.println("Gagal tampil poli: " + e.getMessage());
        }
    }

    public void updatePoli(int idPoli, String nama, String lokasi) {
        String sql = "UPDATE poli SET nama_poli=?, lokasi_poli=? WHERE id_poli=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nama);
            stmt.setString(2, lokasi);
            stmt.setInt(3, idPoli);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data poli berhasil diupdate");
            else System.out.println("Data poli tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update poli: " + e.getMessage());
        }
    }

    public void hapusPoli(int idPoli) {
        String sql = "DELETE FROM poli WHERE id_poli=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPoli);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data poli berhasil dihapus");
            else System.out.println("Data poli tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus poli: " + e.getMessage());
        }
    }
}