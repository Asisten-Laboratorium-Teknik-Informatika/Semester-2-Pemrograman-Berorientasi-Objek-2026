package crud;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import model.Role;

public class RoleM {

    public void tambahRole(Role role) {
        String sql = "INSERT INTO role (nama_role) VALUES (?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, role.getNamaRole());
            stmt.executeUpdate();

            System.out.println("Data role berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah role: " + e.getMessage());
        }
    }

    public void tampilRole() {
        String sql = "SELECT * FROM role";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID   : " + rs.getInt("id_role"));
                System.out.println("Nama : " + rs.getString("nama_role"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data role.");

        } catch (Exception e) {
            System.out.println("Gagal tampil role: " + e.getMessage());
        }
    }

    public void updateRole(int idRole, String namaRole) {
        String sql = "UPDATE role SET nama_role=? WHERE id_role=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, namaRole);
            stmt.setInt(2, idRole);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data role berhasil diupdate");
            else System.out.println("Data role tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update role: " + e.getMessage());
        }
    }

    public void hapusRole(int idRole) {
        String sql = "DELETE FROM role WHERE id_role=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idRole);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data role berhasil dihapus");
            else System.out.println("Data role tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus role: " + e.getMessage());
        }
    }
}