package crud;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import transaksi.Resep;

public class ResepM {

    public void tambahResep(Resep resep) {
        String sql = "INSERT INTO resep (id_pemeriksaan, tanggal_resep) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, resep.getIdPemeriksaan());
            stmt.setDate(2, Date.valueOf(resep.getTanggalResep()));
            stmt.executeUpdate();

            System.out.println("Data resep berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah resep: " + e.getMessage());
        }
    }

    public void tampilResep() {
        String sql = "SELECT * FROM resep";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID             : " + rs.getInt("id_resep"));
                System.out.println("ID Pemeriksaan : " + rs.getInt("id_pemeriksaan"));
                System.out.println("Tanggal        : " + rs.getDate("tanggal_resep"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data resep.");

        } catch (Exception e) {
            System.out.println("Gagal tampil resep: " + e.getMessage());
        }
    }

    public void updateResep(int idResep, int idPemeriksaan, String tanggalResep) {
        String sql = "UPDATE resep SET id_pemeriksaan=?, tanggal_resep=? WHERE id_resep=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPemeriksaan);
            stmt.setDate(2, Date.valueOf(tanggalResep));
            stmt.setInt(3, idResep);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data resep berhasil diupdate");
            else System.out.println("Data resep tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update resep: " + e.getMessage());
        }
    }

    public void hapusResep(int idResep) {
        String sql = "DELETE FROM resep WHERE id_resep=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idResep);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data resep berhasil dihapus");
            else System.out.println("Data resep tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus resep: " + e.getMessage());
        }
    }
}