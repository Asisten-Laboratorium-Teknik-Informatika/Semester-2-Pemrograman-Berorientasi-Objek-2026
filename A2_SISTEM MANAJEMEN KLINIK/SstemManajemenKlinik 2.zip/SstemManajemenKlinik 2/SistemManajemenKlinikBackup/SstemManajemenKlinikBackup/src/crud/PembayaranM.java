package crud;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import transaksi.Pembayaran;

public class PembayaranM {

    public void tambahPembayaran(Pembayaran pembayaran) {
        String sql = "INSERT INTO pembayaran (id_pendaftaran, total_bayar, tanggal_pembayaran, metode_pembayaran, status_pembayaran) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, pembayaran.getIdPendaftaran());
            stmt.setDouble(2, pembayaran.getTotalBayar());
            stmt.setDate(3, Date.valueOf(pembayaran.getTanggalPembayaran()));
            stmt.setString(4, pembayaran.getMetodePembayaran());
            stmt.setString(5, pembayaran.getStatusPembayaran());
            stmt.executeUpdate();

            System.out.println("Data pembayaran berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah pembayaran: " + e.getMessage());
        }
    }

    public void tampilPembayaran() {
        String sql = "SELECT * FROM pembayaran";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID             : " + rs.getInt("id_pembayaran"));
                System.out.println("ID Pendaftaran : " + rs.getInt("id_pendaftaran"));
                System.out.println("Total Bayar    : " + rs.getDouble("total_bayar"));
                System.out.println("Tanggal        : " + rs.getDate("tanggal_pembayaran"));
                System.out.println("Metode         : " + rs.getString("metode_pembayaran"));
                System.out.println("Status         : " + rs.getString("status_pembayaran"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data pembayaran.");

        } catch (Exception e) {
            System.out.println("Gagal tampil pembayaran: " + e.getMessage());
        }
    }

    public void updatePembayaran(int idPembayaran, int idPendaftaran, double totalBayar, String tanggalPembayaran, String metodePembayaran, String statusPembayaran) {
        String sql = "UPDATE pembayaran SET id_pendaftaran=?, total_bayar=?, tanggal_pembayaran=?, metode_pembayaran=?, status_pembayaran=? WHERE id_pembayaran=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPendaftaran);
            stmt.setDouble(2, totalBayar);
            stmt.setDate(3, Date.valueOf(tanggalPembayaran));
            stmt.setString(4, metodePembayaran);
            stmt.setString(5, statusPembayaran);
            stmt.setInt(6, idPembayaran);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data pembayaran berhasil diupdate");
            else System.out.println("Data pembayaran tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update pembayaran: " + e.getMessage());
        }
    }

    public void hapusPembayaran(int idPembayaran) {
        String sql = "DELETE FROM pembayaran WHERE id_pembayaran=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPembayaran);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data pembayaran berhasil dihapus");
            else System.out.println("Data pembayaran tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus pembayaran: " + e.getMessage());
        }
    }
}