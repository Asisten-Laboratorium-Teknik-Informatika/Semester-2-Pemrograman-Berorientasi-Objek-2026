package crud;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import transaksi.Pemeriksaan;

public class PemeriksaanM {

    public void tambahPemeriksaan(Pemeriksaan pemeriksaan) {
        String sql = "INSERT INTO pemeriksaan (id_pendaftaran, id_dokter, tanggal_pemeriksaan, berat_badan, tekanan_darah, diagnosa) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, pemeriksaan.getIdPendaftaran());
            stmt.setInt(2, pemeriksaan.getIdDokter());
            stmt.setDate(3, Date.valueOf(pemeriksaan.getTanggalPemeriksaan()));
            stmt.setDouble(4, pemeriksaan.getBeratBadan());
            stmt.setString(5, pemeriksaan.getTekananDarah());
            stmt.setString(6, pemeriksaan.getDiagnosa());
            stmt.executeUpdate();

            System.out.println("Data pemeriksaan berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah pemeriksaan: " + e.getMessage());
        }
    }

    public void tampilPemeriksaan() {
        String sql = "SELECT * FROM pemeriksaan";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID              : " + rs.getInt("id_pemeriksaan"));
                System.out.println("ID Pendaftaran  : " + rs.getInt("id_pendaftaran"));
                System.out.println("ID Dokter       : " + rs.getInt("id_dokter"));
                System.out.println("Tanggal Periksa : " + rs.getDate("tanggal_pemeriksaan"));
                System.out.println("Berat Badan     : " + rs.getDouble("berat_badan") + " kg");
                System.out.println("Tekanan Darah   : " + rs.getString("tekanan_darah"));
                System.out.println("Diagnosa        : " + rs.getString("diagnosa"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data pemeriksaan.");

        } catch (Exception e) {
            System.out.println("Gagal tampil pemeriksaan: " + e.getMessage());
        }
    }

    public void updatePemeriksaan(int idPemeriksaan, int idPendaftaran, int idDokter, String tanggalPemeriksaan, double beratBadan, String tekananDarah, String diagnosa) {
        String sql = "UPDATE pemeriksaan SET id_pendaftaran=?, id_dokter=?, tanggal_pemeriksaan=?, berat_badan=?, tekanan_darah=?, diagnosa=? WHERE id_pemeriksaan=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPendaftaran);
            stmt.setInt(2, idDokter);
            stmt.setDate(3, Date.valueOf(tanggalPemeriksaan));
            stmt.setDouble(4, beratBadan);
            stmt.setString(5, tekananDarah);
            stmt.setString(6, diagnosa);
            stmt.setInt(7, idPemeriksaan);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data pemeriksaan berhasil diupdate");
            else System.out.println("Data pemeriksaan tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update pemeriksaan: " + e.getMessage());
        }
    }

    public void hapusPemeriksaan(int idPemeriksaan) {
        String sql = "DELETE FROM pemeriksaan WHERE id_pemeriksaan=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPemeriksaan);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data pemeriksaan berhasil dihapus");
            else System.out.println("Data pemeriksaan tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus pemeriksaan: " + e.getMessage());
        }
    }
}