package crud;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import config.DBConnection;
import transaksi.Pendaftaran;

public class PendaftaranM {

    public void tambahPendaftaran(Pendaftaran pendaftaran) {
        String sql = "INSERT INTO pendaftaran (id_pasien, id_poli, tanggal_pendaftaran) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, pendaftaran.getIdPasien());
            stmt.setInt(2, pendaftaran.getIdPoli());
            stmt.setDate(3, Date.valueOf(pendaftaran.getTanggalPendaftaran()));
            stmt.executeUpdate();

            System.out.println("Data pendaftaran berhasil ditambah");
        } catch (Exception e) {
            System.out.println("Gagal tambah pendaftaran: " + e.getMessage());
        }
    }

    public void tampilPendaftaran() {
        String sql = "SELECT * FROM pendaftaran";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.println("ID                              : " + rs.getInt("id_pendaftaran"));
                System.out.println("ID Pasien                       : " + rs.getInt("id_pasien"));
                System.out.println("ID Poli                         : " + rs.getInt("id_poli"));
                System.out.println("Tanggal Pendaftaran             : " + rs.getDate("tanggal_pendaftaran"));
                System.out.println("======================");
            }

            if (!ada) System.out.println("Belum ada data pendaftaran.");

        } catch (Exception e) {
            System.out.println("Gagal tampil pendaftaran: " + e.getMessage());
        }
    }

    public void updatePendaftaran(int idPendaftaran, int idPasien, int idPoli, String tanggalPendaftaran) {
        String sql = "UPDATE pendaftaran SET id_pasien=?, id_poli=?, tanggal_pendaftaran=? WHERE id_pendaftaran=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPasien);
            stmt.setInt(2, idPoli);
            stmt.setDate(3, Date.valueOf(tanggalPendaftaran));
            stmt.setInt(4, idPendaftaran);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data pendaftaran berhasil diupdate");
            else System.out.println("Data pendaftaran tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal update pendaftaran: " + e.getMessage());
        }
    }

    public void hapusPendaftaran(int idPendaftaran) {
        String sql = "DELETE FROM pendaftaran WHERE id_pendaftaran=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPendaftaran);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("Data pendaftaran berhasil dihapus");
            else System.out.println("Data pendaftaran tidak ditemukan");

        } catch (Exception e) {
            System.out.println("Gagal hapus pendaftaran: " + e.getMessage());
        }
    }
}