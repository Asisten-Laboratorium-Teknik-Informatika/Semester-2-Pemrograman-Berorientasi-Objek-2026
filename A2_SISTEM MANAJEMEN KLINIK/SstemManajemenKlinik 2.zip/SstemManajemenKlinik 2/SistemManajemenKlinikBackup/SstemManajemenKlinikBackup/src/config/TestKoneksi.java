package config;

import java.sql.Connection;

public class TestKoneksi {
    public static void main(String[] args) {
        try {
            Connection conn = DBConnection.getConnection();
            System.out.println("✅ Koneksi berhasil!");
            conn.close();
        } catch (Exception e) {
            System.out.println("❌ Koneksi gagal: " + e.getMessage());
        }
    }
}