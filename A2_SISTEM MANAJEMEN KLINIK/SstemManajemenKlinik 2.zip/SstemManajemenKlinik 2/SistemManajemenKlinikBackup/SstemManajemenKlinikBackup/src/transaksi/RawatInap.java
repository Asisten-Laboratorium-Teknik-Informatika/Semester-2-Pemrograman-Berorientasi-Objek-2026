package transaksi;

public class RawatInap {
    private int idRawatInap;
    private int idPendaftaran;
    private String nomorKamar;
    private String tanggalMasuk;
    private String tanggalKeluar;

    public RawatInap(int idRawatInap, int idPendaftaran, String nomorKamar, String tanggalMasuk, String tanggalKeluar) {
        this.idRawatInap = idRawatInap;
        this.idPendaftaran = idPendaftaran;
        this.nomorKamar = nomorKamar;
        this.tanggalMasuk = tanggalMasuk;
        this.tanggalKeluar = tanggalKeluar;
    }

    public int getIdRawatInap() {
        return idRawatInap;
    }

    public String getTanggalMasuk() {
        return tanggalMasuk;
    }

    public String getTanggalKeluar() {
        return tanggalKeluar;
    }

    public String getNomorKamar() {
        return nomorKamar;
    }

    public int getIdPendaftaran() {
        return idPendaftaran;
    }

    public void setIdRawatInap(int idRawatInap) {
        this.idRawatInap = idRawatInap;
    }

    public void setTanggalMasuk(String tanggalMasuk) {
        this.tanggalMasuk = tanggalMasuk;
    }

    public void setTanggalKeluar(String tanggalKeluar) {
        this.tanggalKeluar = tanggalKeluar;
    }

    public void setNomorKamar(String nomorKamar) {
        this.nomorKamar = nomorKamar;
    }

    public void setIdPendaftaran(int idPendaftaran) {
        this.idPendaftaran = idPendaftaran;
    }

}
