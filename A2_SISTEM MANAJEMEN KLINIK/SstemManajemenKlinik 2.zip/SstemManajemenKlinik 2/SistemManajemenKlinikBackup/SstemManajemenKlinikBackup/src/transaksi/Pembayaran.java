package transaksi;

public class Pembayaran {
    private int idPembayaran;
    private int idPendaftaran;
    private double totalBayar;
    private String tanggalPembayaran;
    private String metodePembayaran;
    private String statusPembayaran;

    public Pembayaran(int idPembayaran, int idPendaftaran, double totalBayar, String tanggalPembayaran,
            String metodePembayaran, String statusPembayaran) {
        this.idPembayaran = idPembayaran;
        this.idPendaftaran = idPendaftaran;
        this.totalBayar = totalBayar;
        this.tanggalPembayaran = tanggalPembayaran;
        this.metodePembayaran = metodePembayaran;
        this.statusPembayaran = statusPembayaran;
    }

    public int getIdPembayaran() {
        return idPembayaran;
    }

    public String getTanggalPembayaran() {
        return tanggalPembayaran;
    }

    public double getTotalBayar() {
        return totalBayar;
    }

    public String getMetodePembayaran() {
        return metodePembayaran;
    }

    public int getIdPendaftaran() {
        return idPendaftaran;
    }

    public String getStatusPembayaran() {
        return statusPembayaran;
    }

    public void setIdPembayaran(int idPembayaran) {
        this.idPembayaran = idPembayaran;
    }

    public void setTanggalPembayaran(String tanggalPembayaran) {
        this.tanggalPembayaran = tanggalPembayaran;
    }

    public void setTotalBayar(double totalBayar) {
        this.totalBayar = totalBayar;
    }

    public void setMetodePembayaran(String metodePembayaran) {
        this.metodePembayaran = metodePembayaran;
    }

    public void setIdPendaftaran(int idPendaftaran) {
        this.idPendaftaran = idPendaftaran;
    }

    public void setStatusPembayaran(String statusPembayaran) {
        this.statusPembayaran = statusPembayaran;
    }

}
