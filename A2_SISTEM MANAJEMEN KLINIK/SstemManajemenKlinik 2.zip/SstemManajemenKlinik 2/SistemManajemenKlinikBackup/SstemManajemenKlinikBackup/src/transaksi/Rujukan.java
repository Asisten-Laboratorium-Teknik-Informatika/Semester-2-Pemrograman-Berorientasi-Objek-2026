package transaksi;

public class Rujukan {
    private int idRujukan;
    private int idPasien;
    private String alasanRujukan;
    private String tujuanRujukan;
    private String tanggalRujukan;

    public Rujukan(int idRujukan, int idPasien, String alasanRujukan, String tujuanRujukan, String tanggalRujukan) {
        this.idRujukan = idRujukan;
        this.idPasien = idPasien;
        this.alasanRujukan = alasanRujukan;
        this.tujuanRujukan = tujuanRujukan;
        this.tanggalRujukan = tanggalRujukan;
    }

    public int getIdRujukan() {
        return idRujukan;
    }

    public String getTujuanRujukan() {
        return tujuanRujukan;
    }

    public String getAlasanRujukan() {
        return alasanRujukan;
    }

    public String getTanggalRujukan() {
        return tanggalRujukan;
    }

    public int getIdPasien() {
        return idPasien;
    }

    public void setIdRujukan(int idRujukan) {
        this.idRujukan = idRujukan;
    }

    public void setTujuanRujukan(String tujuanRujukan) {
        this.tujuanRujukan = tujuanRujukan;
    }

    public void setAlasanRujukan(String alasanRujukan) {
        this.alasanRujukan = alasanRujukan;
    }

    public void setTanggalRujukan(String tanggalRujukan) {
        this.tanggalRujukan = tanggalRujukan;
    }

    public void setIdPasien(int idPasien) {
        this.idPasien = idPasien;
    }

}
