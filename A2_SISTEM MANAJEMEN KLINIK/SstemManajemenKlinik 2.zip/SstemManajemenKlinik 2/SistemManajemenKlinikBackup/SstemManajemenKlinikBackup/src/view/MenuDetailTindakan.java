package view;

import java.util.Scanner;
import crud.DetailTindakanM;
import detail.DetailTindakan;

public class MenuDetailTindakan {
    private final DetailTindakanM detailTindakanM = new DetailTindakanM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n=== Menu Detail Tindakan ===");
            System.out.println("1. Tambah Detail Tindakan");
            System.out.println("2. Lihat Semua Detail Tindakan");
            System.out.println("3. Update Detail Tindakan");
            System.out.println("4. Hapus Detail Tindakan");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    tambahDetailTindakan();
                    break;
                case 2:
                    tampilDetailTindakan();
                    break;
                case 3:
                    updateDetailTindakan();
                    break;
                case 4:
                    hapusDetailTindakan();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } while (choice != 5);
    }

    private void tambahDetailTindakan() {
        System.out.print("ID Detail Tindakan : ");
        int idDetailTindakan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pemeriksaan     : ");
        int idPemeriksaan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Tindakan        : ");
        int idTindakan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Jumlah             : ");
        int jumlah = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Subtotal           : ");
        double subtotal = scanner.nextDouble();
        scanner.nextLine();

        detailTindakanM.tambahDetailTindakan(new DetailTindakan(idDetailTindakan, idPemeriksaan, idTindakan, jumlah, subtotal));
    }

    private void tampilDetailTindakan() {
        System.out.println("\nDaftar Detail Tindakan:");
        detailTindakanM.tampilDetailTindakan();
    }

    private void updateDetailTindakan() {
        System.out.print("ID Detail Tindakan yang ingin diupdate: ");
        int idDetailTindakan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pemeriksaan baru : ");
        int idPemeriksaan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Tindakan baru    : ");
        int idTindakan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Jumlah baru         : ");
        int jumlah = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Subtotal baru       : ");
        double subtotal = scanner.nextDouble();
        scanner.nextLine();

        detailTindakanM.updateDetailTindakan(idDetailTindakan, idPemeriksaan, idTindakan, jumlah, subtotal);
    }

    private void hapusDetailTindakan() {
        System.out.print("ID Detail Tindakan yang ingin dihapus: ");
        int idDetailTindakan = scanner.nextInt();
        scanner.nextLine();

        detailTindakanM.hapusDetailTindakan(idDetailTindakan);
    }
}
