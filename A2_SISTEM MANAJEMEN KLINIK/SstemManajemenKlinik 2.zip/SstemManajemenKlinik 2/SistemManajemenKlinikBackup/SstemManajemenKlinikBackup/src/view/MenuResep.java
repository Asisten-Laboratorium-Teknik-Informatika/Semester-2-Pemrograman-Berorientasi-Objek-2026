package view;

import java.util.Scanner;
import crud.ResepM;
import transaksi.Resep;

public class MenuResep {
    private final ResepM resepM = new ResepM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n=== Menu Resep ===");
            System.out.println("1. Tambah Resep");
            System.out.println("2. Lihat Semua Resep");
            System.out.println("3. Update Resep");
            System.out.println("4. Hapus Resep");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    tambahResep();
                    break;
                case 2:
                    tampilResep();
                    break;
                case 3:
                    updateResep();
                    break;
                case 4:
                    hapusResep();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Opsi tidak valid.");
            }
        } while (choice != 5);
    }

    private void tambahResep() {
        System.out.print("ID Resep        : ");
        int idResep = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pemeriksaan  : ");
        int idPemeriksaan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Tanggal Resep   : ");
        String tanggalResep = scanner.nextLine();

        resepM.tambahResep(new Resep(idResep, idPemeriksaan, tanggalResep));
    }

    private void tampilResep() {
        System.out.println("\nDaftar Resep:");
        resepM.tampilResep();
    }

    private void updateResep() {
        System.out.print("ID Resep yang ingin diupdate: ");
        int idResep = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pemeriksaan baru : ");
        int idPemeriksaan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Tanggal Resep baru  : ");
        String tanggalResep = scanner.nextLine();

        resepM.updateResep(idResep, idPemeriksaan, tanggalResep);
    }

    private void hapusResep() {
        System.out.print("ID Resep yang ingin dihapus: ");
        int idResep = scanner.nextInt();
        scanner.nextLine();

        resepM.hapusResep(idResep);
    }
}
