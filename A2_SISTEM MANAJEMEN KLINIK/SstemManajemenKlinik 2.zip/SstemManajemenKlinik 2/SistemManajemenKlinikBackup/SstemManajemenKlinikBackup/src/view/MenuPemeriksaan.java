package view;

import java.util.Scanner;
import crud.PemeriksaanM;
import transaksi.Pemeriksaan;

public class MenuPemeriksaan {
    private final PemeriksaanM pemeriksaanM = new PemeriksaanM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n=== Menu Pemeriksaan ===");
            System.out.println("1. Tambah Pemeriksaan");
            System.out.println("2. Lihat Semua Pemeriksaan");
            System.out.println("3. Update Pemeriksaan");
            System.out.println("4. Hapus Pemeriksaan");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    tambahPemeriksaan();
                    break;
                case 2:
                    tampilPemeriksaan();
                    break;
                case 3:
                    updatePemeriksaan();
                    break;
                case 4:
                    hapusPemeriksaan();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Opsi tidak valid. Silakan coba lagi.");
            }
        } while (choice != 5);
    }

    private void tambahPemeriksaan() {
        System.out.print("ID Pemeriksaan    : ");
        int idPemeriksaan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pendaftaran    : ");
        int idPendaftaran = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Dokter         : ");
        int idDokter = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Tanggal Periksa   : ");
        String tanggalPeriksa = scanner.nextLine();
        System.out.print("Berat Badan (kg)  : ");
        double beratBadan = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Tekanan Darah     : ");
        String tekananDarah = scanner.nextLine();
        System.out.print("Diagnosa          : ");
        String diagnosa = scanner.nextLine();

        pemeriksaanM.tambahPemeriksaan(new Pemeriksaan(idPemeriksaan, idPendaftaran, idDokter, tanggalPeriksa, beratBadan, tekananDarah, diagnosa));
    }

    private void tampilPemeriksaan() {
        System.out.println("\nDaftar Pemeriksaan:");
        pemeriksaanM.tampilPemeriksaan();
    }

    private void updatePemeriksaan() {
        System.out.print("ID Pemeriksaan yang ingin diupdate: ");
        int idPemeriksaan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pendaftaran baru   : ");
        int idPendaftaran = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Dokter baru        : ");
        int idDokter = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Tanggal Periksa baru  : ");
        String tanggalPeriksa = scanner.nextLine();
        System.out.print("Berat Badan baru (kg) : ");
        double beratBadan = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Tekanan Darah baru    : ");
        String tekananDarah = scanner.nextLine();
        System.out.print("Diagnosa baru         : ");
        String diagnosa = scanner.nextLine();

        pemeriksaanM.updatePemeriksaan(idPemeriksaan, idPendaftaran, idDokter, tanggalPeriksa, beratBadan, tekananDarah, diagnosa);
    }

    private void hapusPemeriksaan() {
        System.out.print("ID Pemeriksaan yang ingin dihapus: ");
        int idPemeriksaan = scanner.nextInt();
        scanner.nextLine();

        pemeriksaanM.hapusPemeriksaan(idPemeriksaan);
    }
}
