package view;

import crud.TindakanM;
import java.util.Scanner;
import model.Tindakan;

public class MenuTindakan {
    private final TindakanM tindakanM = new TindakanM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n=== Menu Tindakan ===");
            System.out.println("1. Tambah Tindakan");
            System.out.println("2. Lihat Semua Tindakan");
            System.out.println("3. Update Tindakan");
            System.out.println("4. Hapus Tindakan");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    tambahTindakan();
                    break;
                case 2:
                    tampilTindakan();
                    break;
                case 3:
                    updateTindakan();
                    break;
                case 4:
                    hapusTindakan();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } while (choice != 5);
    }

    private void tambahTindakan() {
        System.out.print("ID Tindakan    : ");
        int idTindakan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nama Tindakan  : ");
        String namaTindakan = scanner.nextLine();
        System.out.print("Biaya Tindakan : ");
        double biayaTindakan = scanner.nextDouble();
        scanner.nextLine();

        tindakanM.tambahTindakan(new Tindakan(idTindakan, namaTindakan, biayaTindakan));
    }

    private void tampilTindakan() {
        System.out.println("\nDaftar Tindakan:");
        tindakanM.tampilTindakan();
    }

    private void updateTindakan() {
        System.out.print("ID Tindakan yang ingin diupdate: ");
        int idTindakan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nama Tindakan baru  : ");
        String namaTindakan = scanner.nextLine();
        System.out.print("Biaya Tindakan baru : ");
        double biayaTindakan = scanner.nextDouble();
        scanner.nextLine();

        tindakanM.updateTindakan(idTindakan, namaTindakan, biayaTindakan);
    }

    private void hapusTindakan() {
        System.out.print("ID Tindakan yang ingin dihapus: ");
        int idTindakan = scanner.nextInt();
        scanner.nextLine();

        tindakanM.hapusTindakan(idTindakan);
    }
}
