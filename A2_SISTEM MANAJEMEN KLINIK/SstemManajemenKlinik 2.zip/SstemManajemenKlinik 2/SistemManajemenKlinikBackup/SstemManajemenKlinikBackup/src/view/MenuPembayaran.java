package view;

import java.util.Scanner;
import crud.PembayaranM;
import transaksi.Pembayaran;

public class MenuPembayaran {
    private final PembayaranM pembayaranM = new PembayaranM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n=== Menu Pembayaran ===");
            System.out.println("1. Tambah Pembayaran");
            System.out.println("2. Lihat Semua Pembayaran");
            System.out.println("3. Update Pembayaran");
            System.out.println("4. Hapus Pembayaran");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    tambahPembayaran();
                    break;
                case 2:
                    tampilPembayaran();
                    break;
                case 3:
                    updatePembayaran();
                    break;
                case 4:
                    hapusPembayaran();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } while (choice != 5);
    }

    private void tambahPembayaran() {
        System.out.print("ID Pembayaran     : ");
        int idPembayaran = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pendaftaran    : ");
        int idPendaftaran = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Total Bayar       : ");
        double totalBayar = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Tanggal Bayar     : ");
        String tanggalBayar = scanner.nextLine();
        System.out.print("Metode Pembayaran : ");
        String metodePembayaran = scanner.nextLine();
        System.out.print("Status Pembayaran : ");
        String statusPembayaran = scanner.nextLine();

        pembayaranM.tambahPembayaran(new Pembayaran(idPembayaran, idPendaftaran, totalBayar, tanggalBayar, metodePembayaran, statusPembayaran));
    }

    private void tampilPembayaran() {
        System.out.println("\nDaftar Pembayaran:");
        pembayaranM.tampilPembayaran();
    }

    private void updatePembayaran() {
        System.out.print("ID Pembayaran yang ingin diupdate: ");
        int idPembayaran = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pendaftaran baru    : ");
        int idPendaftaran = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Total Bayar baru       : ");
        double totalBayar = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Tanggal Bayar baru     : ");
        String tanggalBayar = scanner.nextLine();
        System.out.print("Metode Pembayaran baru : ");
        String metodePembayaran = scanner.nextLine();
        System.out.print("Status Pembayaran baru : ");
        String statusPembayaran = scanner.nextLine();

        pembayaranM.updatePembayaran(idPembayaran, idPendaftaran, totalBayar, tanggalBayar, metodePembayaran, statusPembayaran);
    }

    private void hapusPembayaran() {
        System.out.print("ID Pembayaran yang ingin dihapus: ");
        int idPembayaran = scanner.nextInt();
        scanner.nextLine();

        pembayaranM.hapusPembayaran(idPembayaran);
    }
}
