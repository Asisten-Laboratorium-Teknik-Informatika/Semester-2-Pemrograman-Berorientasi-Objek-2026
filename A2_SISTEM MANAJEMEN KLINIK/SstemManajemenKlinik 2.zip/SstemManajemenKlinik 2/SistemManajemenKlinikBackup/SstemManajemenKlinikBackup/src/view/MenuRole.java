package view;

import crud.RoleM;
import java.util.Scanner;
import model.Role;

public class MenuRole {
    private final RoleM roleM = new RoleM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        int choice;
        do {
            System.out.println("=== Menu Role ===");
            System.out.println("1. Tambah Role");
            System.out.println("2. Lihat Semua Role");
            System.out.println("3. Update Role");
            System.out.println("4. Hapus Role");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();
            scanner.nextLine();

           switch (choice) {
                case 1:
                    tambahRole();
                    break;
                case 2:
                    lihatSemuaRole();
                    break;
                case 3:
                    updateRole();
                    break;
                case 4:
                    deleteRole();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }

        } while (choice != 5);
    }

    private void tambahRole() {
        System.out.print("Masukkan nama role: ");
        String namaRole = scanner.nextLine();
        Role role = new Role(0, namaRole);
        roleM.tambahRole(role);

    }

    private void lihatSemuaRole() {
        System.out.println("Daftar Role:");
        roleM.tampilRole();
    }
    private void updateRole() {
        System.out.print("Masukkan ID role yang ingin diupdate: ");
        int idRole = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Masukkan nama role baru: ");
        String namaRole = scanner.nextLine();

        roleM.updateRole(idRole, namaRole);
        System.out.println("Role berhasil diupdate.");
    }

    private void deleteRole() {
        System.out.print("Masukkan ID role yang ingin dihapus: ");
        int idRole = scanner.nextInt();
        scanner.nextLine();
        roleM.hapusRole(idRole);

    }
}
