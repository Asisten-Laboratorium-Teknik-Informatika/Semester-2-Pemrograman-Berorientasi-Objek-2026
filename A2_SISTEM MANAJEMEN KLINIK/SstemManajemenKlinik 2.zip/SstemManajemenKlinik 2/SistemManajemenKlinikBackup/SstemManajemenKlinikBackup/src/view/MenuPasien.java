package view;

import java.util.Scanner;
import crud.PasienM;
import model.Pasien;

public class MenuPasien {
    private final PasienM pasienM = new PasienM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n=== Menu Pasien ===");
            System.out.println("1. Tambah Pasien");
            System.out.println("2. Lihat Semua Pasien");
            System.out.println("3. Update Pasien");
            System.out.println("4. Hapus Pasien");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    tambahPasien();
                    break;
                case 2:
                    tampilPasien();
                    break;
                case 3:
                    updatePasien();
                    break;
                case 4:
                    hapusPasien();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } while (choice != 5);
    }

    private void tambahPasien() {
        System.out.print("ID Pasien        : ");
        int idPasien = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nama Pasien      : ");
        String namaPasien = scanner.nextLine();
        System.out.print("Jenis Kelamin    : ");
        String jenisKelamin = scanner.nextLine();
        System.out.print("Tanggal Lahir    : ");
        String tanggalLahir = scanner.nextLine();
        System.out.print("Alamat           : ");
        String alamat = scanner.nextLine();
        System.out.print("No HP            : ");
        String noHp = scanner.nextLine();
        System.out.print("Golongan Darah   : ");
        String golonganDarah = scanner.nextLine();

        pasienM.tambahPasien(new Pasien(idPasien, namaPasien, jenisKelamin, tanggalLahir, alamat, noHp, golonganDarah));
    }

    private void tampilPasien() {
        System.out.println("\nDaftar Pasien:");
        pasienM.tampilPasien();
    }

    private void updatePasien() {
        System.out.print("ID Pasien yang ingin diupdate: ");
        int idPasien = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nama Pasien baru    : ");
        String namaPasien = scanner.nextLine();
        System.out.print("Jenis Kelamin baru  : ");
        String jenisKelamin = scanner.nextLine();
        System.out.print("Tanggal Lahir baru  : ");
        String tanggalLahir = scanner.nextLine();
        System.out.print("Alamat baru         : ");
        String alamat = scanner.nextLine();
        System.out.print("No HP baru          : ");
        String noHp = scanner.nextLine();
        System.out.print("Golongan Darah baru : ");
        String golonganDarah = scanner.nextLine();

        pasienM.updatePasien(idPasien, namaPasien, jenisKelamin, tanggalLahir, alamat, noHp, golonganDarah);
    }

    private void hapusPasien() {
        System.out.print("ID Pasien yang ingin dihapus: ");
        int idPasien = scanner.nextInt();
        scanner.nextLine();

        pasienM.hapusPasien(idPasien);
    }
}
