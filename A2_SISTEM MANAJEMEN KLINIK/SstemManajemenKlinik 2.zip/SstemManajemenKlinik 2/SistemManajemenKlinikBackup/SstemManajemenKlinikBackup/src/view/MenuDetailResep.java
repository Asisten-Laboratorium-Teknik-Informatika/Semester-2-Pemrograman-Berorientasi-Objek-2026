package view;

import java.util.Scanner;
import crud.DetailResepM;
import detail.DetailResep;

public class MenuDetailResep {
    private final DetailResepM detailResepM = new DetailResepM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n=== Menu Detail Resep ===");
            System.out.println("1. Tambah Detail Resep");
            System.out.println("2. Lihat Semua Detail Resep");
            System.out.println("3. Update Detail Resep");
            System.out.println("4. Hapus Detail Resep");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    tambahDetailResep();
                    break;
                case 2:
                    tampilDetailResep();
                    break;
                case 3:
                    updateDetailResep();
                    break;
                case 4:
                    hapusDetailResep();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Opsi tidak valid. Silakan coba lagi.");
            }
        } while (choice != 5);
    }

    private void tambahDetailResep() {
        System.out.print("ID Detail Resep : ");
        int idDetailResep = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Resep        : ");
        int idResep = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Obat         : ");
        int idObat = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Jumlah Obat     : ");
        int jumlahObat = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Dosis           : ");
        String dosis = scanner.nextLine();

        detailResepM.tambahDetailResep(new DetailResep(idDetailResep, idResep, idObat, jumlahObat, dosis));
    }

    private void tampilDetailResep() {
        System.out.println("\nDaftar Detail Resep:");
        detailResepM.tampilDetailResep();
    }

    private void updateDetailResep() {
        System.out.print("ID Detail Resep yang ingin diupdate: ");
        int idDetailResep = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Resep baru    : ");
        int idResep = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Obat baru     : ");
        int idObat = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Jumlah Obat baru : ");
        int jumlahObat = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Dosis baru       : ");
        String dosis = scanner.nextLine();

        detailResepM.updateDetailResep(idDetailResep, idResep, idObat, jumlahObat, dosis);
    }

    private void hapusDetailResep() {
        System.out.print("ID Detail Resep yang ingin dihapus: ");
        int idDetailResep = scanner.nextInt();
        scanner.nextLine();

        detailResepM.hapusDetailResep(idDetailResep);
    }
}
