package view;

import java.util.Scanner;

public class MenuUtama {
    private final Scanner scanner = new Scanner(System.in);

    private final MenuRole menuRole = new MenuRole();
    private final MenuPoli menuPoli = new MenuPoli();
    private final MenuTindakan menuTindakan = new MenuTindakan();
    private final MenuObat menuObat = new MenuObat();
    private final MenuPasien menuPasien = new MenuPasien();
    private final MenuPegawai menuPegawai = new MenuPegawai();
    private final MenuDokter menuDokter = new MenuDokter();

    private final MenuDetailResep menuDetailResep = new MenuDetailResep();
    private final MenuDetailTindakan menuDetailTindakan = new MenuDetailTindakan();

    private final MenuPendaftaran menuPendaftaran = new MenuPendaftaran();
    private final MenuPemeriksaan menuPemeriksaan = new MenuPemeriksaan();
    private final MenuLabTest menuLabTest = new MenuLabTest();
    private final MenuResep menuResep = new MenuResep();
    private final MenuRawatInap menuRawatInap = new MenuRawatInap();
    private final MenuRujukan menuRujukan = new MenuRujukan();
    private final MenuPembayaran menuPembayaran = new MenuPembayaran();

    public void tampilMenuUtama() {
        int choice;
        do {
            System.out.println("\n========================================");
            System.out.println("      SISTEM MANAJEMEN KLINIK");
            System.out.println("========================================");
            System.out.println("--- Data Administrasi ---");
            System.out.println(" 1. Manajemen Role");
            System.out.println(" 2. Manajemen Poli");
            System.out.println(" 3. Manajemen Tindakan");
            System.out.println(" 4. Manajemen Obat");
            System.out.println(" 5. Manajemen Pasien");
            System.out.println(" 6. Manajemen Pegawai");
            System.out.println(" 7. Manajemen Dokter");

             System.out.println("--- Rincian dan Detail Layanan ---");
            System.out.println(" 8. Detail Resep");
            System.out.println(" 9. Detail Tindakan");

            System.out.println("--- Transaksi ---");
            System.out.println(" 10. Pendaftaran");
            System.out.println(" 11. Pemeriksaan");
            System.out.println(" 12. Lab Test");
            System.out.println(" 13. Resep");
            System.out.println(" 14. Rawat Inap");
            System.out.println(" 15. Rujukan");
            System.out.println(" 16. Pembayaran");
            System.out.println("----------------------------------------");
            System.out.println(" 0. Keluar");
            System.out.println("========================================");
            System.out.print("Pilih menu: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                    case 1:
                        menuRole.displayMenu();
                        break;
                    case 2:
                        menuPoli.displayMenu();
                        break;
                    case 3:
                        menuTindakan.displayMenu();
                        break;
                    case 4:
                        menuObat.displayMenu();
                        break;
                    case 5:
                        menuPasien.displayMenu();
                        break;
                    case 6:
                        menuPegawai.displayMenu();
                        break;
                    case 7:
                        menuDokter.displayMenu();
                        break;
                    case 8:
                        menuDetailResep.displayMenu();
                        break;
                    case 9:
                        menuDetailTindakan.displayMenu();
                        break;
                    case 10:
                        menuPendaftaran.displayMenu();
                        break;
                    case 11:
                        menuPemeriksaan.displayMenu();
                        break;
                    case 12:
                        menuLabTest.displayMenu();
                        break;
                    case 13:
                        menuResep.displayMenu();
                        break;
                    case 14:
                        menuRawatInap.displayMenu();
                        break;
                    case 15:
                        menuRujukan.displayMenu();
                        break;
                    case 16:
                        menuPembayaran.displayMenu();
                        break;
                    case 0:
                        System.out.println("Terima kasih telah menggunakan sistem. Sampai jumpa!");
                        break;
                    default:
                        System.out.println("Pilihan tidak valid. Silakan coba lagi.");
                }
        } while (choice != 0);
    }
}
