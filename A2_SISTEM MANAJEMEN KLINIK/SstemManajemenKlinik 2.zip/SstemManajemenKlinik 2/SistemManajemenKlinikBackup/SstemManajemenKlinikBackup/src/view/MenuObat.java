package view;

import java.util.Scanner;
import crud.ObatM;
import model.Obat;

public class MenuObat {
    private final ObatM obatM = new ObatM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n=== Menu Obat ===");
            System.out.println("1. Tambah Obat");
            System.out.println("2. Lihat Semua Obat");
            System.out.println("3. Update Obat");
            System.out.println("4. Hapus Obat");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    tambahObat();
                    break;
                case 2:
                    lihatSemuaObat();
                    break;
                case 3:
                    updateObat();
                    break;
                case 4:
                    hapusObat();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } while (choice != 5);
    }

    private void tambahObat() {
        System.out.print("ID Obat    : ");
        int idObat = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nama Obat  : ");
        String namaObat = scanner.nextLine();
        System.out.print("Jenis Obat : ");
        String jenisObat = scanner.nextLine();
        System.out.print("Harga Obat : ");
        double hargaObat = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Stok       : ");
        int stok = scanner.nextInt();
        scanner.nextLine();

        obatM.tambahObat(new Obat(idObat, namaObat, jenisObat, hargaObat, stok));
    }

    private void lihatSemuaObat() {
        System.out.println("\nDaftar Obat:");
        obatM.tampilObat();
    }

    private void updateObat() {
        System.out.print("ID Obat yang ingin diupdate: ");
        int idObat = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nama Obat baru  : ");
        String namaObat = scanner.nextLine();
        System.out.print("Jenis Obat baru : ");
        String jenisObat = scanner.nextLine();
        System.out.print("Harga Obat baru : ");
        double hargaObat = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Stok baru       : ");
        int stok = scanner.nextInt();
        scanner.nextLine();

        obatM.updateObat(idObat, namaObat, jenisObat, hargaObat, stok);
    }

    private void hapusObat() {
        System.out.print("ID Obat yang ingin dihapus: ");
        int idObat = scanner.nextInt();
        scanner.nextLine();

        obatM.hapusObat(idObat);
    }
}
