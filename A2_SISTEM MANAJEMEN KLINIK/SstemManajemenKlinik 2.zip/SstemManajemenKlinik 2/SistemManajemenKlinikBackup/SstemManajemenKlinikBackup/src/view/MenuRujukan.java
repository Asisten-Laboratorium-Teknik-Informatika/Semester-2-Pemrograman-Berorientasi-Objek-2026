package view;

import java.util.Scanner;
import crud.RujukanM;
import transaksi.Rujukan;

public class MenuRujukan {
    private final RujukanM rujukanM = new RujukanM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n=== Menu Rujukan ===");
            System.out.println("1. Tambah Rujukan");
            System.out.println("2. Lihat Semua Rujukan");
            System.out.println("3. Update Rujukan");
            System.out.println("4. Hapus Rujukan");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    tambahRujukan();
                    break;
                case 2:
                    tampilRujukan();
                    break;
                case 3:
                    updateRujukan();
                    break;
                case 4:
                    hapusRujukan();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } while (choice != 5);
    }

    private void tambahRujukan() {
        System.out.print("ID Rujukan          : ");
        int idRujukan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pasien           : ");
        int idPasien = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Alasan Rujukan      : ");
        String alasanRujukan = scanner.nextLine();
        System.out.print("Rumah Sakit Tujuan  : ");
        String tujuanRujukan = scanner.nextLine();
        System.out.print("Tanggal Rujukan     : ");
        String tanggalRujukan = scanner.nextLine();

        rujukanM.tambahRujukan(new Rujukan(idRujukan, idPasien, alasanRujukan, tujuanRujukan, tanggalRujukan));
    }

    private void tampilRujukan() {
        System.out.println("\nDaftar Rujukan:");
        rujukanM.tampilRujukan();
    }

    private void updateRujukan() {
        System.out.print("ID Rujukan yang ingin diupdate: ");
        int idRujukan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pasien baru          : ");
        int idPasien = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Alasan Rujukan baru     : ");
        String alasanRujukan = scanner.nextLine();
        System.out.print("Tujuan Rujukan baru : ");
        String tujuanRujukan = scanner.nextLine();
        System.out.print("Tanggal Rujukan baru    : ");
        String tanggalRujukan = scanner.nextLine();

        rujukanM.updateRujukan(idRujukan, idPasien, alasanRujukan, tujuanRujukan, tanggalRujukan);
    }

    private void hapusRujukan() {
        System.out.print("ID Rujukan yang ingin dihapus: ");
        int idRujukan = scanner.nextInt();
        scanner.nextLine();

        rujukanM.hapusRujukan(idRujukan);
    }
}
