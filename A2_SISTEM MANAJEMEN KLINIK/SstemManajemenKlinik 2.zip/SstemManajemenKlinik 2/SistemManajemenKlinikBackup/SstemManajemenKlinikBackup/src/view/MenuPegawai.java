package view;

import java.util.Scanner;
import crud.PegawaiM;
import model.Pegawai;

public class MenuPegawai {
    private final PegawaiM pegawaiM = new PegawaiM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n=== Menu Pegawai ===");
            System.out.println("1. Tambah Pegawai");
            System.out.println("2. Lihat Semua Pegawai");
            System.out.println("3. Update Pegawai");
            System.out.println("4. Hapus Pegawai");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    tambahPegawai();
                    break;
                case 2:
                    tampilPegawai();
                    break;
                case 3:
                    updatePegawai();
                    break;
                case 4:
                    hapusPegawai();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } while (choice != 5);
    }

    private void tambahPegawai() {
        System.out.print("ID Pegawai  : ");
        int idPegawai = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nama        : ");
        String namaPegawai = scanner.nextLine();
        System.out.print("Alamat      : ");
        String alamat = scanner.nextLine();
        System.out.print("No HP       : ");
        String noHp = scanner.nextLine();
        System.out.print("Email       : ");
        String email = scanner.nextLine();
        System.out.print("Username    : ");
        String username = scanner.nextLine();
        System.out.print("Password    : ");
        String password = scanner.nextLine();
        System.out.print("ID Role     : ");
        int idRole = scanner.nextInt();
        scanner.nextLine();

        pegawaiM.tambahPegawai(new Pegawai(idPegawai, namaPegawai, alamat, noHp, email, username, password, idRole));
    }

    private void tampilPegawai() {
        System.out.println("\nDaftar Pegawai:");
        pegawaiM.tampilPegawai();
    }

    private void updatePegawai() {
        System.out.print("ID Pegawai yang ingin diupdate: ");
        int idPegawai = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nama baru       : ");
        String namaPegawai = scanner.nextLine();
        System.out.print("Alamat baru     : ");
        String alamat = scanner.nextLine();
        System.out.print("No HP baru      : ");
        String noHp = scanner.nextLine();
        System.out.print("Email baru      : ");
        String email = scanner.nextLine();
        System.out.print("Username baru   : ");
        String username = scanner.nextLine();
        System.out.print("Password baru   : ");
        String password = scanner.nextLine();
        System.out.print("ID Role baru    : ");
        int idRole = scanner.nextInt();
        scanner.nextLine();

        pegawaiM.updatePegawai(idPegawai, namaPegawai, alamat, noHp, email, username, password, idRole);
    }

    private void hapusPegawai() {
        System.out.print("ID Pegawai yang ingin dihapus: ");
        int idPegawai = scanner.nextInt();
        scanner.nextLine();

        pegawaiM.hapusPegawai(idPegawai);
    }
}
