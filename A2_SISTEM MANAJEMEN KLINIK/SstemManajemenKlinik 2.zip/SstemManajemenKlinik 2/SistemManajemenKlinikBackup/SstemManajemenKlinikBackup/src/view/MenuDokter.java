package view;

import java.util.Scanner;
import crud.DokterM;
import model.Dokter;

public class MenuDokter {
    private final DokterM dokterM = new DokterM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n=== Menu Dokter ===");
            System.out.println("1. Tambah Dokter");
            System.out.println("2. Lihat Semua Dokter");
            System.out.println("3. Update Dokter");
            System.out.println("4. Hapus Dokter");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    tambahDokter();
                    break;
                case 2:
                    tampilDokter();
                    break;
                case 3:
                    updateDokter();
                    break;
                case 4:
                    hapusDokter();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } while (choice != 5);
    }

    private void tambahDokter() {
        System.out.print("ID Dokter   : ");
        int idDokter = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nama Dokter : ");
        String namaDokter = scanner.nextLine();
        System.out.print("Spesialis   : ");
        String spesialis = scanner.nextLine();
        System.out.print("No HP       : ");
        String noHp = scanner.nextLine();
        System.out.print("ID Poli     : ");
        int idPoli = scanner.nextInt();
        scanner.nextLine();

        dokterM.tambahDokter(new Dokter(idDokter, namaDokter, spesialis, noHp, idPoli));
    }

    private void tampilDokter() {
        System.out.println("\nDaftar Dokter:");
        dokterM.tampilDokter();
    }

    private void updateDokter() {
        System.out.print("ID Dokter yang ingin diupdate: ");
        int idDokter = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nama Dokter baru : ");
        String namaDokter = scanner.nextLine();
        System.out.print("Spesialis baru   : ");
        String spesialis = scanner.nextLine();
        System.out.print("No HP baru       : ");
        String noHp = scanner.nextLine();
        System.out.print("ID Poli baru     : ");
        int idPoli = scanner.nextInt();
        scanner.nextLine();

        dokterM.updateDokter(idDokter, namaDokter, spesialis, noHp, idPoli);
    }

    private void hapusDokter() {
        System.out.print("ID Dokter yang ingin dihapus: ");
        int idDokter = scanner.nextInt();
        scanner.nextLine();

        dokterM.hapusDokter(idDokter);
    }
}
