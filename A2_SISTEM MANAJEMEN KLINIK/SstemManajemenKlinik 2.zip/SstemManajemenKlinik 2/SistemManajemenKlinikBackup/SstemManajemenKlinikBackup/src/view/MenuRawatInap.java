package view;

import java.util.Scanner;
import crud.RawatInapM;
import transaksi.RawatInap;

public class MenuRawatInap {
    private final RawatInapM rawatInapM = new RawatInapM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n=== Menu Rawat Inap ===");
            System.out.println("1. Tambah Rawat Inap");
            System.out.println("2. Lihat Semua Rawat Inap");
            System.out.println("3. Update Rawat Inap");
            System.out.println("4. Hapus Rawat Inap");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    tambahRawatInap();
                    break;
                case 2:
                    tampilRawatInap();
                    break;
                case 3:
                    updateRawatInap();
                    break;
                case 4:
                    hapusRawatInap();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } while (choice != 5);
    }

    private void tambahRawatInap() {
        System.out.print("ID Rawat Inap   : ");
        int idRawatInap = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pasien       : ");
        int idPasien = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nomor Kamar     : ");
        String nomorKamar = scanner.nextLine();
        System.out.print("Tanggal Masuk   : ");
        String tanggalMasuk = scanner.nextLine();
        System.out.print("Tanggal Keluar  : ");
        String tanggalKeluar = scanner.nextLine();

        rawatInapM.tambahRawatInap(new RawatInap(idRawatInap, idPasien, nomorKamar, tanggalMasuk, tanggalKeluar));
    }

    private void tampilRawatInap() {
        System.out.println("\nDaftar Rawat Inap:");
        rawatInapM.tampilRawatInap();
    }

    private void updateRawatInap() {
        System.out.print("ID Rawat Inap yang ingin diupdate: ");
        int idRawatInap = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pasien baru      : ");
        int idPasien = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nomor Kamar baru    : ");
        String nomorKamar = scanner.nextLine();
        System.out.print("Tanggal Masuk baru  : ");
        String tanggalMasuk = scanner.nextLine();
        System.out.print("Tanggal Keluar baru : ");
        String tanggalKeluar = scanner.nextLine();

        rawatInapM.updateRawatInap(idRawatInap, idPasien, nomorKamar, tanggalMasuk, tanggalKeluar);
    }

    private void hapusRawatInap() {
        System.out.print("ID Rawat Inap yang ingin dihapus: ");
        int idRawatInap = scanner.nextInt();
        scanner.nextLine();

        rawatInapM.hapusRawatInap(idRawatInap);
    }
}
