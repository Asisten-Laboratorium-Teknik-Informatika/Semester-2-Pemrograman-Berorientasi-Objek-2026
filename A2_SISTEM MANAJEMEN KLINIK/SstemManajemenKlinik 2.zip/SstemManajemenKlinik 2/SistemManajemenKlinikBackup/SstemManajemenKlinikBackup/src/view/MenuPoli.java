package view;

import crud.PoliM;
import java.util.Scanner;
import model.Poli;

public class MenuPoli {
    private final PoliM poliM = new PoliM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu(){
        int choice;
        do {
            System.out.println("\n=== Menu Poli ===");
            System.out.println("1. Tambah Poli");
            System.out.println("2. Tampilkan Semua Poli");
            System.out.println("3. Update Poli");
            System.out.println("4. Hapus Poli");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih menu: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    tambahPoli();
                    break;
                case 2:
                    tampilPoli();
                    break;
                case 3:
                    updatePoli();
                    break;
                case 4:
                    hapusPoli();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } while (choice != 5);
    }

    private void tambahPoli() {
        System.out.print("ID Poli     : ");
        int idPoli = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nama Poli   : ");
        String namaPoli = scanner.nextLine();
        System.out.print("Lokasi Poli : ");
        String lokasiPoli = scanner.nextLine();

        poliM.tambahPoli(new Poli(idPoli, namaPoli, lokasiPoli));
    }

    private void tampilPoli() {
        System.out.println("\nDaftar Poli:");
        poliM.tampilPoli();
    }

     private void updatePoli() {
        System.out.print("ID Poli yang ingin diupdate: ");
        int idPoli = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nama Poli baru  : ");
        String namaPoli = scanner.nextLine();
        System.out.print("Lokasi Poli baru: ");
        String lokasiPoli = scanner.nextLine();

        poliM.updatePoli(idPoli, namaPoli, lokasiPoli);
    }

    private void hapusPoli() {
        System.out.print("ID Poli yang ingin dihapus: ");
        int idPoli = scanner.nextInt();
        scanner.nextLine();

        poliM.hapusPoli(idPoli);
    }
}
