package view;

import java.util.Scanner;
import crud.LabTestM;
import transaksi.LabTest;

public class MenuLabTest {
    private final LabTestM labTestM = new LabTestM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n=== Menu Lab Test ===");
            System.out.println("1. Tambah Lab Test");
            System.out.println("2. Lihat Semua Lab Test");
            System.out.println("3. Update Lab Test");
            System.out.println("4. Hapus Lab Test");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    tambahLabTest();
                    break;
                case 2:
                    lihatSemuaLabTest();
                    break;
                case 3:
                    updateLabTest();
                    break;
                case 4:
                    hapusLabTest();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Opsi tidak valid. Silakan coba lagi.");
            }
        } while (choice != 5);
    }

    private void tambahLabTest() {
        System.out.print("ID Lab          : ");
        int idLab = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pemeriksaan  : ");
        int idPemeriksaan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Jenis Test      : ");
        String jenisTest = scanner.nextLine();
        System.out.print("Hasil Test      : ");
        String hasilTest = scanner.nextLine();
        System.out.print("Tanggal Test    : ");
        String tanggalTest = scanner.nextLine();

        labTestM.tambahLabTest(new LabTest(idLab, idPemeriksaan, jenisTest, hasilTest, tanggalTest));
    }

    private void lihatSemuaLabTest() {
        System.out.println("\nDaftar Lab Test:");
        labTestM.tampilLabTest();
    }

    private void updateLabTest() {
        System.out.print("ID Lab yang ingin diupdate: ");
        int idLab = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pemeriksaan baru : ");
        int idPemeriksaan = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Jenis Test baru     : ");
        String jenisTest = scanner.nextLine();
        System.out.print("Hasil Test baru     : ");
        String hasilTest = scanner.nextLine();
        System.out.print("Tanggal Test baru   : ");
        String tanggalTest = scanner.nextLine();

        labTestM.updateLabTest(idLab, idPemeriksaan, jenisTest, hasilTest, tanggalTest);
    }

    private void hapusLabTest() {
        System.out.print("ID Lab yang ingin dihapus: ");
        int idLab = scanner.nextInt();
        scanner.nextLine();

        labTestM.hapusLabTest(idLab);
    }
}
