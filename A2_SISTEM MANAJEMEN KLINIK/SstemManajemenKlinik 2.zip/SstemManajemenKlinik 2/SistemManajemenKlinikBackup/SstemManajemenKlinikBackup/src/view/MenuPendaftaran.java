package view;

import crud.PendaftaranM;
import java.util.Scanner;
import transaksi.Pendaftaran;

public class MenuPendaftaran {
    private final PendaftaranM pendaftaranM = new PendaftaranM();
    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n=== Menu Pendaftaran ===");
            System.out.println("1. Tambah Pendaftaran");
            System.out.println("2. Lihat Semua Pendaftaran");
            System.out.println("3. Update Pendaftaran");
            System.out.println("4. Hapus Pendaftaran");
            System.out.println("5. Kembali ke Menu Utama");
            System.out.print("Pilih opsi: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    tambahPendaftaran();
                    break;
                case 2:
                    tampilPendaftaran();
                    break;
                case 3:
                    updatePendaftaran();
                    break;
                case 4:
                    hapusPendaftaran();
                    break;
                case 5:
                    System.out.println("Kembali ke Menu Utama...");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } while (choice != 5);
    }

    private void tambahPendaftaran() {
        System.out.print("ID Pendaftaran    : ");
        int idPendaftaran = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pasien         : ");
        int idPasien = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Poli           : ");
        int idPoli = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Tanggal Daftar    : ");
        String tanggalPendaftaran = scanner.nextLine();

        pendaftaranM.tambahPendaftaran(new Pendaftaran(idPendaftaran, idPasien, idPoli, tanggalPendaftaran));
    }

    private void tampilPendaftaran() {
        System.out.println("\nDaftar Pendaftaran:");
        pendaftaranM.tampilPendaftaran();
    }

    private void updatePendaftaran() {
        System.out.print("ID Pendaftaran yang ingin diupdate: ");
        int idPendaftaran = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Pasien baru         : ");
        int idPasien = scanner.nextInt();
        scanner.nextLine();
        System.out.print("ID Poli baru           : ");
        int idPoli = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Tanggal Daftar baru    : ");
        String tanggalPendaftaran = scanner.nextLine();

        pendaftaranM.updatePendaftaran(idPendaftaran, idPasien, idPoli, tanggalPendaftaran);
    }

    private void hapusPendaftaran() {
        System.out.print("ID Pendaftaran yang ingin dihapus: ");
        int idPendaftaran = scanner.nextInt();
        scanner.nextLine();

        pendaftaranM.hapusPendaftaran(idPendaftaran);
    }
}
