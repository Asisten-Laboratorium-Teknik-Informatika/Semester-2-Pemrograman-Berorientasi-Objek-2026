Project sudah dibersihkan dari file hasil build.

Compile dengan javac:
  javac -d out $(find src -name "*.java")

Compile dengan Maven:
  mvn package

Main class: Main
