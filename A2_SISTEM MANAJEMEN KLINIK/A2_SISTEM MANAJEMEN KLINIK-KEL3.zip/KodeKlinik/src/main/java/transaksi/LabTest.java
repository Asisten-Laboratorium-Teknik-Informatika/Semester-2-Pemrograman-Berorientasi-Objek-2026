package transaksi;

public class LabTest {

    private int idLabTest;
    private int idPemeriksaan;
    private String jenisTest;
    private String hasilTest;
    private String tanggalTest;

    public LabTest(int idLabTest, int idPemeriksaan, String jenisTest, String hasilTest, String tanggalTest) {
        this.idLabTest = idLabTest;
        this.idPemeriksaan = idPemeriksaan;
        this.jenisTest = jenisTest;
        this.hasilTest = hasilTest;
        this.tanggalTest = tanggalTest;
    }

    public int getIdLabTest() {
        return idLabTest;
    }

    public int getIdPemeriksaan() {
        return idPemeriksaan;
    }

    public String getJenisTest() {
        return jenisTest;
    }

    public String getHasilTest() {
        return hasilTest;
    }

    public String getTanggalTest() {
        return tanggalTest;
    }

    public void setIdLabTest(int idLabTest) {
        this.idLabTest = idLabTest;
    }

    public void setIdPemeriksaan(int idPemeriksaan) {
        this.idPemeriksaan = idPemeriksaan;
    }

    public void setJenisTest(String jenisTest) {
        this.jenisTest = jenisTest;
    }

    public void setHasilTest(String hasilTest) {
        this.hasilTest = hasilTest;
    }

    public void setTanggalTest(String tanggalTest) {
        this.tanggalTest = tanggalTest;
    }

}