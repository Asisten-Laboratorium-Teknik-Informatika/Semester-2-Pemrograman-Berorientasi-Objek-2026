package crud;

import java.sql.SQLException;
import java.util.List;
import transaksi.Pendaftaran;

public class PendaftaranM extends CrudSupport<Pendaftaran> {
    private static final String SELECT_ALL_SQL = "SELECT id_pendaftaran, id_pasien, id_poli, tanggal_pendaftaran FROM pendaftaran ORDER BY id_pendaftaran";
    private static final String SELECT_BY_ID_SQL = "SELECT id_pendaftaran, id_pasien, id_poli, tanggal_pendaftaran FROM pendaftaran WHERE id_pendaftaran = ?";
    private static final String UPDATE_SQL = "UPDATE pendaftaran SET id_pasien = ?, id_poli = ?, tanggal_pendaftaran = ? WHERE id_pendaftaran = ?";
    private static final String DELETE_SQL = "DELETE FROM pendaftaran WHERE id_pendaftaran = ?";

    public List<Pendaftaran> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new Pendaftaran(rs.getInt("id_pendaftaran"), rs.getInt("id_pasien"), rs.getInt("id_poli"), toDateString(rs.getDate("tanggal_pendaftaran"))));
    }

    public Pendaftaran findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new Pendaftaran(rs.getInt("id_pendaftaran"), rs.getInt("id_pasien"), rs.getInt("id_poli"), toDateString(rs.getDate("tanggal_pendaftaran"))), id);
    }

    public boolean insert(Pendaftaran entity) throws SQLException {
        return execute("INSERT INTO pendaftaran (id_pasien, id_poli) VALUES (?, ?)", entity.getIdPasien(), entity.getIdPoli()) > 0;
    }

    public boolean update(Pendaftaran entity) throws SQLException {
        return execute("UPDATE pendaftaran SET id_pasien = ?, id_poli = ?, tanggal_pendaftaran = ? WHERE id_pendaftaran = ?", entity.getIdPasien(), entity.getIdPoli(), toSqlDate(entity.getTanggalPendaftaran()), entity.getIdPendaftaran()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM pendaftaran WHERE id_pendaftaran = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("pendaftaran");
    }
}