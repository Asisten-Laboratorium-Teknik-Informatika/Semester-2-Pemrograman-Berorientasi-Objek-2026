package crud;

import java.sql.SQLException;
import java.util.List;
import transaksi.Resep;

public class ResepM extends CrudSupport<Resep> {
    private static final String SELECT_ALL_SQL = "SELECT id_resep, id_pemeriksaan, tanggal_resep FROM resep ORDER BY id_resep";
    private static final String SELECT_BY_ID_SQL = "SELECT id_resep, id_pemeriksaan, tanggal_resep FROM resep WHERE id_resep = ?";
    private static final String UPDATE_SQL = "UPDATE resep SET id_pemeriksaan = ?, tanggal_resep = ? WHERE id_resep = ?";
    private static final String DELETE_SQL = "DELETE FROM resep WHERE id_resep = ?";

    public List<Resep> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new Resep(rs.getInt("id_resep"), rs.getInt("id_pemeriksaan"), toDateString(rs.getDate("tanggal_resep"))));
    }

    public Resep findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new Resep(rs.getInt("id_resep"), rs.getInt("id_pemeriksaan"), toDateString(rs.getDate("tanggal_resep"))), id);
    }

    public boolean insert(Resep entity) throws SQLException {
        return execute("INSERT INTO resep (id_pemeriksaan) VALUES (?)", entity.getIdPemeriksaan()) > 0;
    }

    public boolean update(Resep entity) throws SQLException {
        return execute("UPDATE resep SET id_pemeriksaan = ?, tanggal_resep = ? WHERE id_resep = ?", entity.getIdPemeriksaan(), toSqlDate(entity.getTanggalResep()), entity.getIdResep()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM resep WHERE id_resep = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("resep");
    }
}