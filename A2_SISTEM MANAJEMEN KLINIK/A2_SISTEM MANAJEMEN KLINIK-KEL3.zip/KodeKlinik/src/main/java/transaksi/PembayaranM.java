package crud;

import java.sql.SQLException;
import java.util.List;
import transaksi.Pembayaran;

public class PembayaranM extends CrudSupport<Pembayaran> {
    private static final String SELECT_ALL_SQL = "SELECT id_pembayaran, id_pendaftaran, total_bayar, tanggal_pembayaran, metode_pembayaran, status_pembayaran FROM pembayaran ORDER BY id_pembayaran";
    private static final String SELECT_BY_ID_SQL = "SELECT id_pembayaran, id_pendaftaran, total_bayar, tanggal_pembayaran, metode_pembayaran, status_pembayaran FROM pembayaran WHERE id_pembayaran = ?";
    private static final String UPDATE_SQL = "UPDATE pembayaran SET id_pendaftaran = ?, total_bayar = ?, tanggal_pembayaran = ?, metode_pembayaran = ?, status_pembayaran = ? WHERE id_pembayaran = ?";
    private static final String DELETE_SQL = "DELETE FROM pembayaran WHERE id_pembayaran = ?";

    public List<Pembayaran> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new Pembayaran(rs.getInt("id_pembayaran"), rs.getInt("id_pendaftaran"), rs.getDouble("total_bayar"), toDateString(rs.getDate("tanggal_pembayaran")), rs.getString("metode_pembayaran"), rs.getString("status_pembayaran")));
    }

    public Pembayaran findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new Pembayaran(rs.getInt("id_pembayaran"), rs.getInt("id_pendaftaran"), rs.getDouble("total_bayar"), toDateString(rs.getDate("tanggal_pembayaran")), rs.getString("metode_pembayaran"), rs.getString("status_pembayaran")), id);
    }

    public boolean insert(Pembayaran entity) throws SQLException {
        execute("CALL sp_buat_pembayaran(?, ?)", entity.getIdPendaftaran(), entity.getMetodePembayaran());
        return true;
    }

    public boolean update(Pembayaran entity) throws SQLException {
        return execute("UPDATE pembayaran SET id_pendaftaran = ?, total_bayar = ?, tanggal_pembayaran = ?, metode_pembayaran = ?, status_pembayaran = ? WHERE id_pembayaran = ?", entity.getIdPendaftaran(), entity.getTotalBayar(), toSqlDate(entity.getTanggalPembayaran()), entity.getMetodePembayaran(), entity.getStatusPembayaran(), entity.getIdPembayaran()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM pembayaran WHERE id_pembayaran = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("pembayaran");
    }
}