package crud;

import java.sql.SQLException;
import java.util.List;
import transaksi.Rujukan;

public class RujukanM extends CrudSupport<Rujukan> {
    private static final String SELECT_ALL_SQL = "SELECT id_rujukan, id_pasien, alasan_rujukan, tujuan_rujukan, tanggal_rujukan FROM rujukan ORDER BY id_rujukan";
    private static final String SELECT_BY_ID_SQL = "SELECT id_rujukan, id_pasien, alasan_rujukan, tujuan_rujukan, tanggal_rujukan FROM rujukan WHERE id_rujukan = ?";
    private static final String UPDATE_SQL = "UPDATE rujukan SET id_pasien = ?, alasan_rujukan = ?, tujuan_rujukan = ?, tanggal_rujukan = ? WHERE id_rujukan = ?";
    private static final String DELETE_SQL = "DELETE FROM rujukan WHERE id_rujukan = ?";

    public List<Rujukan> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new Rujukan(rs.getInt("id_rujukan"), rs.getInt("id_pasien"), rs.getString("alasan_rujukan"), rs.getString("tujuan_rujukan"), toDateString(rs.getDate("tanggal_rujukan"))));
    }

    public Rujukan findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new Rujukan(rs.getInt("id_rujukan"), rs.getInt("id_pasien"), rs.getString("alasan_rujukan"), rs.getString("tujuan_rujukan"), toDateString(rs.getDate("tanggal_rujukan"))), id);
    }

    public boolean insert(Rujukan entity) throws SQLException {
        return execute("INSERT INTO rujukan (id_pasien, alasan_rujukan, tujuan_rujukan) VALUES (?, ?, ?)", entity.getIdPasien(), entity.getAlasanRujukan(), entity.getTujuanRujukan()) > 0;
    }

    public boolean update(Rujukan entity) throws SQLException {
        return execute("UPDATE rujukan SET id_pasien = ?, alasan_rujukan = ?, tujuan_rujukan = ?, tanggal_rujukan = ? WHERE id_rujukan = ?", entity.getIdPasien(), entity.getAlasanRujukan(), entity.getTujuanRujukan(), toSqlDate(entity.getTanggalRujukan()), entity.getIdRujukan()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM rujukan WHERE id_rujukan = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("rujukan");
    }
}