package crud;

import java.sql.SQLException;
import java.util.List;
import transaksi.LabTest;

public class LabTestM extends CrudSupport<LabTest> {
    private static final String SELECT_ALL_SQL = "SELECT id_lab_test, id_pemeriksaan, jenis_test, hasil_test, tanggal_test FROM lab_test ORDER BY id_lab_test";
    private static final String SELECT_BY_ID_SQL = "SELECT id_lab_test, id_pemeriksaan, jenis_test, hasil_test, tanggal_test FROM lab_test WHERE id_lab_test = ?";
    private static final String UPDATE_SQL = "UPDATE lab_test SET id_pemeriksaan = ?, jenis_test = ?, hasil_test = ?, tanggal_test = ? WHERE id_lab_test = ?";
    private static final String DELETE_SQL = "DELETE FROM lab_test WHERE id_lab_test = ?";

    public List<LabTest> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new LabTest(rs.getInt("id_lab_test"), rs.getInt("id_pemeriksaan"), rs.getString("jenis_test"), rs.getString("hasil_test"), toDateString(rs.getDate("tanggal_test"))));
    }

    public LabTest findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new LabTest(rs.getInt("id_lab_test"), rs.getInt("id_pemeriksaan"), rs.getString("jenis_test"), rs.getString("hasil_test"), toDateString(rs.getDate("tanggal_test"))), id);
    }

    public boolean insert(LabTest entity) throws SQLException {
        return execute("INSERT INTO lab_test (id_pemeriksaan, jenis_test, hasil_test) VALUES (?, ?, ?)", entity.getIdPemeriksaan(), entity.getJenisTest(), entity.getHasilTest()) > 0;
    }

    public boolean update(LabTest entity) throws SQLException {
        return execute("UPDATE lab_test SET id_pemeriksaan = ?, jenis_test = ?, hasil_test = ?, tanggal_test = ? WHERE id_lab_test = ?", entity.getIdPemeriksaan(), entity.getJenisTest(), entity.getHasilTest(), toSqlDate(entity.getTanggalTest()), entity.getIdLabTest()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM lab_test WHERE id_lab_test = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("lab_test");
    }
}