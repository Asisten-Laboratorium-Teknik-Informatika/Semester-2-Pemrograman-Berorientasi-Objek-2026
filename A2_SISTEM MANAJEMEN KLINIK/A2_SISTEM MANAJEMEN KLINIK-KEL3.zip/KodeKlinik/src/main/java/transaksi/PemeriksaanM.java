package crud;

import java.sql.SQLException;
import java.util.List;
import transaksi.Pemeriksaan;

public class PemeriksaanM extends CrudSupport<Pemeriksaan> {
    private static final String SELECT_ALL_SQL = "SELECT id_pemeriksaan, id_pendaftaran, id_dokter, tanggal_pemeriksaan, berat_badan, tekanan_darah, diagnosa FROM pemeriksaan ORDER BY id_pemeriksaan";
    private static final String SELECT_BY_ID_SQL = "SELECT id_pemeriksaan, id_pendaftaran, id_dokter, tanggal_pemeriksaan, berat_badan, tekanan_darah, diagnosa FROM pemeriksaan WHERE id_pemeriksaan = ?";
    private static final String UPDATE_SQL = "UPDATE pemeriksaan SET id_pendaftaran = ?, id_dokter = ?, tanggal_pemeriksaan = ?, berat_badan = ?, tekanan_darah = ?, diagnosa = ? WHERE id_pemeriksaan = ?";
    private static final String DELETE_SQL = "DELETE FROM pemeriksaan WHERE id_pemeriksaan = ?";

    public List<Pemeriksaan> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new Pemeriksaan(rs.getInt("id_pemeriksaan"), rs.getInt("id_pendaftaran"), rs.getInt("id_dokter"), toDateString(rs.getDate("tanggal_pemeriksaan")), rs.getDouble("berat_badan"), rs.getString("tekanan_darah"), rs.getString("diagnosa")));
    }

    public Pemeriksaan findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new Pemeriksaan(rs.getInt("id_pemeriksaan"), rs.getInt("id_pendaftaran"), rs.getInt("id_dokter"), toDateString(rs.getDate("tanggal_pemeriksaan")), rs.getDouble("berat_badan"), rs.getString("tekanan_darah"), rs.getString("diagnosa")), id);
    }

    public boolean insert(Pemeriksaan entity) throws SQLException {
        return execute("INSERT INTO pemeriksaan (id_pendaftaran, id_dokter, berat_badan, tekanan_darah, diagnosa) VALUES (?, ?, ?, ?, ?)", entity.getIdPendaftaran(), entity.getIdDokter(), entity.getBeratBadan(), entity.getTekananDarah(), entity.getDiagnosa()) > 0;
    }

    public boolean update(Pemeriksaan entity) throws SQLException {
        return execute("UPDATE pemeriksaan SET id_pendaftaran = ?, id_dokter = ?, tanggal_pemeriksaan = ?, berat_badan = ?, tekanan_darah = ?, diagnosa = ? WHERE id_pemeriksaan = ?", entity.getIdPendaftaran(), entity.getIdDokter(), toSqlDate(entity.getTanggalPemeriksaan()), entity.getBeratBadan(), entity.getTekananDarah(), entity.getDiagnosa(), entity.getIdPemeriksaan()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM pemeriksaan WHERE id_pemeriksaan = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("pemeriksaan");
    }
}