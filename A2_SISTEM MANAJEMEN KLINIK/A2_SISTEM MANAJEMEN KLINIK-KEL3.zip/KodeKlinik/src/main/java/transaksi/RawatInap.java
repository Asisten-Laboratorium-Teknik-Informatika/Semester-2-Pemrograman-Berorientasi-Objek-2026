package transaksi;

public class RawatInap {

    private int idRawatInap;
    private int idPendaftaran;
    private String nomorKamar;
    private String tanggalMasuk;
    private String tanggalKeluar;

    public RawatInap(int idRawatInap, int idPendaftaran, String nomorKamar, String tanggalMasuk, String tanggalKeluar) {
        this.idRawatInap = idRawatInap;
        this.idPendaftaran = idPendaftaran;
        this.nomorKamar = nomorKamar;
        this.tanggalMasuk = tanggalMasuk;
        this.tanggalKeluar = tanggalKeluar;
    }

    public int getIdRawatInap() {
        return idRawatInap;
    }

    public int getIdPendaftaran() {
        return idPendaftaran;
    }

    public String getNomorKamar() {
        return nomorKamar;
    }

    public String getTanggalMasuk() {
        return tanggalMasuk;
    }

    public String getTanggalKeluar() {
        return tanggalKeluar;
    }

    public void setIdRawatInap(int idRawatInap) {
        this.idRawatInap = idRawatInap;
    }

    public void setIdPendaftaran(int idPendaftaran) {
        this.idPendaftaran = idPendaftaran;
    }

    public void setNomorKamar(String nomorKamar) {
        this.nomorKamar = nomorKamar;
    }

    public void setTanggalMasuk(String tanggalMasuk) {
        this.tanggalMasuk = tanggalMasuk;
    }

    public void setTanggalKeluar(String tanggalKeluar) {
        this.tanggalKeluar = tanggalKeluar;
    }

}