package transaksi;

public class Pendaftaran {

    private int idPendaftaran;
    private int idPasien;
    private int idPoli;
    private String tanggalPendaftaran;

    public Pendaftaran(int idPendaftaran, int idPasien, int idPoli, String tanggalPendaftaran) {
        this.idPendaftaran = idPendaftaran;
        this.idPasien = idPasien;
        this.idPoli = idPoli;
        this.tanggalPendaftaran = tanggalPendaftaran;
    }

    public int getIdPendaftaran() {
        return idPendaftaran;
    }

    public int getIdPasien() {
        return idPasien;
    }

    public int getIdPoli() {
        return idPoli;
    }

    public String getTanggalPendaftaran() {
        return tanggalPendaftaran;
    }

    public void setIdPendaftaran(int idPendaftaran) {
        this.idPendaftaran = idPendaftaran;
    }

    public void setIdPasien(int idPasien) {
        this.idPasien = idPasien;
    }

    public void setIdPoli(int idPoli) {
        this.idPoli = idPoli;
    }

    public void setTanggalPendaftaran(String tanggalPendaftaran) {
        this.tanggalPendaftaran = tanggalPendaftaran;
    }

}