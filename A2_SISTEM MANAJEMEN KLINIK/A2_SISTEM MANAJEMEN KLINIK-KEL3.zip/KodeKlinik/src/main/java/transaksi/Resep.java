package transaksi;

public class Resep {

    private int idResep;
    private int idPemeriksaan;
    private String tanggalResep;

    public Resep(int idResep, int idPemeriksaan, String tanggalResep) {
        this.idResep = idResep;
        this.idPemeriksaan = idPemeriksaan;
        this.tanggalResep = tanggalResep;
    }

    public int getIdResep() {
        return idResep;
    }

    public int getIdPemeriksaan() {
        return idPemeriksaan;
    }

    public String getTanggalResep() {
        return tanggalResep;
    }

    public void setIdResep(int idResep) {
        this.idResep = idResep;
    }

    public void setIdPemeriksaan(int idPemeriksaan) {
        this.idPemeriksaan = idPemeriksaan;
    }

    public void setTanggalResep(String tanggalResep) {
        this.tanggalResep = tanggalResep;
    }

}