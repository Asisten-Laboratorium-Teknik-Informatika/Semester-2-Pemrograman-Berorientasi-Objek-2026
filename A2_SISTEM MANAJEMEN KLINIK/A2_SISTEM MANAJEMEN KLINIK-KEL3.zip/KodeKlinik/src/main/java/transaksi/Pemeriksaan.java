package transaksi;

public class Pemeriksaan {

    private int idPemeriksaan;
    private int idPendaftaran;
    private int idDokter;
    private String tanggalPemeriksaan;
    private double beratBadan;
    private String tekananDarah;
    private String diagnosa;

    public Pemeriksaan(int idPemeriksaan, int idPendaftaran, int idDokter, String tanggalPemeriksaan, double beratBadan, String tekananDarah, String diagnosa) {
        this.idPemeriksaan = idPemeriksaan;
        this.idPendaftaran = idPendaftaran;
        this.idDokter = idDokter;
        this.tanggalPemeriksaan = tanggalPemeriksaan;
        this.beratBadan = beratBadan;
        this.tekananDarah = tekananDarah;
        this.diagnosa = diagnosa;
    }

    public int getIdPemeriksaan() {
        return idPemeriksaan;
    }

    public int getIdPendaftaran() {
        return idPendaftaran;
    }

    public int getIdDokter() {
        return idDokter;
    }

    public String getTanggalPemeriksaan() {
        return tanggalPemeriksaan;
    }

    public double getBeratBadan() {
        return beratBadan;
    }

    public String getTekananDarah() {
        return tekananDarah;
    }

    public String getDiagnosa() {
        return diagnosa;
    }

    public void setIdPemeriksaan(int idPemeriksaan) {
        this.idPemeriksaan = idPemeriksaan;
    }

    public void setIdPendaftaran(int idPendaftaran) {
        this.idPendaftaran = idPendaftaran;
    }

    public void setIdDokter(int idDokter) {
        this.idDokter = idDokter;
    }

    public void setTanggalPemeriksaan(String tanggalPemeriksaan) {
        this.tanggalPemeriksaan = tanggalPemeriksaan;
    }

    public void setBeratBadan(double beratBadan) {
        this.beratBadan = beratBadan;
    }

    public void setTekananDarah(String tekananDarah) {
        this.tekananDarah = tekananDarah;
    }

    public void setDiagnosa(String diagnosa) {
        this.diagnosa = diagnosa;
    }

}