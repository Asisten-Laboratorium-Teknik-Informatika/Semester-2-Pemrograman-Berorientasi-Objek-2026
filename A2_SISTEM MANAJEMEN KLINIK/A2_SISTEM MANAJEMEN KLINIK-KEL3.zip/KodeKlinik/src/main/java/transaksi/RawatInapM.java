package crud;

import java.sql.SQLException;
import java.util.List;
import transaksi.RawatInap;

public class RawatInapM extends CrudSupport<RawatInap> {
    private static final String SELECT_ALL_SQL = "SELECT id_rawat_inap, id_pendaftaran, nomor_kamar, tanggal_masuk, tanggal_keluar FROM rawat_inap ORDER BY id_rawat_inap";
    private static final String SELECT_BY_ID_SQL = "SELECT id_rawat_inap, id_pendaftaran, nomor_kamar, tanggal_masuk, tanggal_keluar FROM rawat_inap WHERE id_rawat_inap = ?";
    private static final String UPDATE_SQL = "UPDATE rawat_inap SET id_pendaftaran = ?, nomor_kamar = ?, tanggal_masuk = ?, tanggal_keluar = ? WHERE id_rawat_inap = ?";
    private static final String DELETE_SQL = "DELETE FROM rawat_inap WHERE id_rawat_inap = ?";

    public List<RawatInap> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new RawatInap(rs.getInt("id_rawat_inap"), rs.getInt("id_pendaftaran"), rs.getString("nomor_kamar"), toDateString(rs.getDate("tanggal_masuk")), toDateString(rs.getDate("tanggal_keluar"))));
    }

    public RawatInap findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new RawatInap(rs.getInt("id_rawat_inap"), rs.getInt("id_pendaftaran"), rs.getString("nomor_kamar"), toDateString(rs.getDate("tanggal_masuk")), toDateString(rs.getDate("tanggal_keluar"))), id);
    }

    public boolean insert(RawatInap entity) throws SQLException {
        return execute("INSERT INTO rawat_inap (id_pendaftaran, nomor_kamar, tanggal_masuk, tanggal_keluar) VALUES (?, ?, ?, ?)", entity.getIdPendaftaran(), entity.getNomorKamar(), toSqlDate(entity.getTanggalMasuk()), toSqlDate(entity.getTanggalKeluar())) > 0;
    }

    public boolean update(RawatInap entity) throws SQLException {
        return execute("UPDATE rawat_inap SET id_pendaftaran = ?, nomor_kamar = ?, tanggal_masuk = ?, tanggal_keluar = ? WHERE id_rawat_inap = ?", entity.getIdPendaftaran(), entity.getNomorKamar(), toSqlDate(entity.getTanggalMasuk()), toSqlDate(entity.getTanggalKeluar()), entity.getIdRawatInap()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM rawat_inap WHERE id_rawat_inap = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("rawat_inap");
    }
}