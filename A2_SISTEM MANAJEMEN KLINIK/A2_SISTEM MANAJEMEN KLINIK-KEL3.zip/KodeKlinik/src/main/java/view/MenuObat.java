package view;

import crud.*;
import model.Obat;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuObat {
    private final ObatM crud = new ObatM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu Obat");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            Obat entity = new Obat(0, InputHelper.text("Nama obat"), InputHelper.text("Jenis obat"), InputHelper.decimal("Harga obat"), InputHelper.integer("Stok"));
            crud.insert(entity);
            ConsoleUI.success("Data obat berhasil disimpan.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<Obat> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (Obat entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdObat()), safe(entity.getNamaObat()), safe(entity.getJenisObat()), String.valueOf(entity.getHargaObat()), String.valueOf(entity.getStok())});
            }
            ConsoleUI.printTable("Data Obat", new String[]{"ID", "Nama obat", "Jenis obat", "Harga obat", "Stok"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            Obat entity = new Obat(id, InputHelper.text("Nama obat"), InputHelper.text("Jenis obat"), InputHelper.decimal("Harga obat"), InputHelper.integer("Stok"));
            crud.update(entity);
            ConsoleUI.success("Data obat berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data obat berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}