package view;

import crud.*;
import model.Tindakan;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuTindakan {
    private final TindakanM crud = new TindakanM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu Tindakan");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            Tindakan entity = new Tindakan(0, InputHelper.text("Nama tindakan"), InputHelper.decimal("Biaya tindakan"));
            crud.insert(entity);
            ConsoleUI.success("Data tindakan berhasil disimpan.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<Tindakan> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (Tindakan entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdTindakan()), safe(entity.getNamaTindakan()), String.valueOf(entity.getBiayaTindakan())});
            }
            ConsoleUI.printTable("Data Tindakan", new String[]{"ID", "Nama tindakan", "Biaya tindakan"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            Tindakan entity = new Tindakan(id, InputHelper.text("Nama tindakan"), InputHelper.decimal("Biaya tindakan"));
            crud.update(entity);
            ConsoleUI.success("Data tindakan berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data tindakan berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}