package view;

import crud.*;
import model.Poli;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuPoli {
    private final PoliM crud = new PoliM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu Poli");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            Poli entity = new Poli(0, InputHelper.text("Nama poli"), InputHelper.text("Lokasi poli"));
            crud.insert(entity);
            ConsoleUI.success("Data poli berhasil disimpan.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<Poli> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (Poli entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdPoli()), safe(entity.getNamaPoli()), safe(entity.getLokasiPoli())});
            }
            ConsoleUI.printTable("Data Poli", new String[]{"ID", "Nama poli", "Lokasi poli"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            Poli entity = new Poli(id, InputHelper.text("Nama poli"), InputHelper.text("Lokasi poli"));
            crud.update(entity);
            ConsoleUI.success("Data poli berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data poli berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}