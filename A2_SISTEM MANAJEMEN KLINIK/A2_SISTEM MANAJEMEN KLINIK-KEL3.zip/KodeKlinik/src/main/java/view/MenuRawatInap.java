package view;

import crud.*;
import transaksi.RawatInap;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuRawatInap {
    private final RawatInapM crud = new RawatInapM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu RawatInap");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            RawatInap entity = new RawatInap(0, InputHelper.integer("ID pendaftaran"), InputHelper.text("Nomor kamar"), InputHelper.date("Tanggal masuk (YYYY-MM-DD)"), InputHelper.optionalDate("Tanggal keluar (opsional, kosongkan jika belum)"));
            crud.insert(entity);
            ConsoleUI.success("Data rawatinap berhasil disimpan.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<RawatInap> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (RawatInap entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdRawatInap()), String.valueOf(entity.getIdPendaftaran()), safe(entity.getNomorKamar()), safe(entity.getTanggalMasuk()), safe(entity.getTanggalKeluar())});
            }
            ConsoleUI.printTable("Data RawatInap", new String[]{"ID", "ID pendaftaran", "Nomor kamar", "Tanggal masuk (YYYY-MM-DD)", "Tanggal keluar (opsional, kosongkan jika belum)"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            RawatInap entity = new RawatInap(id, InputHelper.integer("ID pendaftaran"), InputHelper.text("Nomor kamar"), InputHelper.date("Tanggal masuk (YYYY-MM-DD)"), InputHelper.optionalDate("Tanggal keluar (opsional, kosongkan jika belum)"));
            crud.update(entity);
            ConsoleUI.success("Data rawatinap berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data rawatinap berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}