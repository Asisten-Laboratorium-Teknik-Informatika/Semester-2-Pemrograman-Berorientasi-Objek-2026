package view;

import crud.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Role;
import model.Poli;
import model.Pasien;
import model.Pegawai;
import model.Dokter;
import model.Tindakan;
import model.Obat;
import transaksi.Pendaftaran;
import transaksi.Pemeriksaan;
import transaksi.Resep;
import detail.DetailResep;
import detail.DetailTindakan;
import transaksi.LabTest;
import transaksi.RawatInap;
import transaksi.Rujukan;
import transaksi.Pembayaran;

public class MenuUtama {
    private final RoleM roleCrud = new RoleM();
    private final PoliM poliCrud = new PoliM();
    private final PasienM pasienCrud = new PasienM();
    private final PegawaiM pegawaiCrud = new PegawaiM();
    private final DokterM dokterCrud = new DokterM();
    private final TindakanM tindakanCrud = new TindakanM();
    private final ObatM obatCrud = new ObatM();
    private final PendaftaranM pendaftaranCrud = new PendaftaranM();
    private final PemeriksaanM pemeriksaanCrud = new PemeriksaanM();
    private final ResepM resepCrud = new ResepM();
    private final DetailResepM detailResepCrud = new DetailResepM();
    private final DetailTindakanM detailTindakanCrud = new DetailTindakanM();
    private final LabTestM labTestCrud = new LabTestM();
    private final RawatInapM rawatInapCrud = new RawatInapM();
    private final RujukanM rujukanCrud = new RujukanM();
    private final PembayaranM pembayaranCrud = new PembayaranM();
    private final MenuRole menuRole = new MenuRole();
    private final MenuPoli menuPoli = new MenuPoli();
    private final MenuPasien menuPasien = new MenuPasien();
    private final MenuPegawai menuPegawai = new MenuPegawai();
    private final MenuDokter menuDokter = new MenuDokter();
    private final MenuTindakan menuTindakan = new MenuTindakan();
    private final MenuObat menuObat = new MenuObat();
    private final MenuPendaftaran menuPendaftaran = new MenuPendaftaran();
    private final MenuPemeriksaan menuPemeriksaan = new MenuPemeriksaan();
    private final MenuResep menuResep = new MenuResep();
    private final MenuDetailResep menuDetailResep = new MenuDetailResep();
    private final MenuDetailTindakan menuDetailTindakan = new MenuDetailTindakan();
    private final MenuLabTest menuLabTest = new MenuLabTest();
    private final MenuRawatInap menuRawatInap = new MenuRawatInap();
    private final MenuRujukan menuRujukan = new MenuRujukan();
    private final MenuPembayaran menuPembayaran = new MenuPembayaran();
    private final MenuLaporan menuLaporan = new MenuLaporan();

    public void tampilMenuUtama() {
        while (true) {
            ConsoleUI.banner("KODE KLINIK");
            showSummary();
            ConsoleUI.section("Data Master");
            ConsoleUI.info("1. Role");
            ConsoleUI.info("2. Poli");
            ConsoleUI.info("3. Pasien");
            ConsoleUI.info("4. Pegawai");
            ConsoleUI.info("5. Dokter");
            ConsoleUI.info("6. Tindakan");
            ConsoleUI.info("7. Obat");
            ConsoleUI.section("Transaksi");
            ConsoleUI.info("8. Pendaftaran");
            ConsoleUI.info("9. Pemeriksaan");
            ConsoleUI.info("10. Resep");
            ConsoleUI.info("11. Detail Resep");
            ConsoleUI.info("12. Detail Tindakan");
            ConsoleUI.info("13. Lab Test");
            ConsoleUI.info("14. Rawat Inap");
            ConsoleUI.info("15. Rujukan");
            ConsoleUI.info("16. Pembayaran");
            ConsoleUI.section("Laporan");
            ConsoleUI.info("17. Laporan view");
            ConsoleUI.info("0. Keluar");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 17);
            if (choice == 0) {
                ConsoleUI.info("Sampai jumpa.");
                return;
            }
            switch (choice) {
                case 1 -> menuRole.displayMenu();
                case 2 -> menuPoli.displayMenu();
                case 3 -> menuPasien.displayMenu();
                case 4 -> menuPegawai.displayMenu();
                case 5 -> menuDokter.displayMenu();
                case 6 -> menuTindakan.displayMenu();
                case 7 -> menuObat.displayMenu();
                case 8 -> menuPendaftaran.displayMenu();
                case 9 -> menuPemeriksaan.displayMenu();
                case 10 -> menuResep.displayMenu();
                case 11 -> menuDetailResep.displayMenu();
                case 12 -> menuDetailTindakan.displayMenu();
                case 13 -> menuLabTest.displayMenu();
                case 14 -> menuRawatInap.displayMenu();
                case 15 -> menuRujukan.displayMenu();
                case 16 -> menuPembayaran.displayMenu();
                case 17 -> menuLaporan.displayMenu();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void showSummary() {
        try {
            List<String[]> rows = new ArrayList<>();
            rows.add(new String[]{"Role", String.valueOf(roleCrud.count())});
            rows.add(new String[]{"Poli", String.valueOf(poliCrud.count())});
            rows.add(new String[]{"Pasien", String.valueOf(pasienCrud.count())});
            rows.add(new String[]{"Pegawai", String.valueOf(pegawaiCrud.count())});
            rows.add(new String[]{"Dokter", String.valueOf(dokterCrud.count())});
            rows.add(new String[]{"Tindakan", String.valueOf(tindakanCrud.count())});
            rows.add(new String[]{"Obat", String.valueOf(obatCrud.count())});
            rows.add(new String[]{"Pendaftaran", String.valueOf(pendaftaranCrud.count())});
            rows.add(new String[]{"Pemeriksaan", String.valueOf(pemeriksaanCrud.count())});
            rows.add(new String[]{"Resep", String.valueOf(resepCrud.count())});
            rows.add(new String[]{"DetailResep", String.valueOf(detailResepCrud.count())});
            rows.add(new String[]{"DetailTindakan", String.valueOf(detailTindakanCrud.count())});
            rows.add(new String[]{"LabTest", String.valueOf(labTestCrud.count())});
            rows.add(new String[]{"RawatInap", String.valueOf(rawatInapCrud.count())});
            rows.add(new String[]{"Rujukan", String.valueOf(rujukanCrud.count())});
            rows.add(new String[]{"Pembayaran", String.valueOf(pembayaranCrud.count())});
            ConsoleUI.printTable("Ringkasan data", new String[]{"Modul", "Jumlah"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error("Ringkasan gagal dimuat: " + e.getMessage());
        }
    }
}