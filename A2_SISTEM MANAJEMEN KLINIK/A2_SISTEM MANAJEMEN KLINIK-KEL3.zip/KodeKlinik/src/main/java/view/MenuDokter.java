package view;

import crud.*;
import model.Dokter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuDokter {
    private final DokterM crud = new DokterM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu Dokter");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            Dokter entity = new Dokter(0, InputHelper.text("Nama dokter"), InputHelper.text("Spesialis"), InputHelper.text("No HP"), InputHelper.integer("ID poli"));
            crud.insert(entity);
            ConsoleUI.success("Data dokter berhasil disimpan.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<Dokter> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (Dokter entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdDokter()), safe(entity.getNamaDokter()), safe(entity.getSpesialis()), safe(entity.getNoHp()), String.valueOf(entity.getIdPoli())});
            }
            ConsoleUI.printTable("Data Dokter", new String[]{"ID", "Nama dokter", "Spesialis", "No HP", "ID poli"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            Dokter entity = new Dokter(id, InputHelper.text("Nama dokter"), InputHelper.text("Spesialis"), InputHelper.text("No HP"), InputHelper.integer("ID poli"));
            crud.update(entity);
            ConsoleUI.success("Data dokter berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data dokter berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}