package view;

import crud.*;
import transaksi.Rujukan;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuRujukan {
    private final RujukanM crud = new RujukanM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu Rujukan");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            Rujukan entity = new Rujukan(0, InputHelper.integer("ID pasien"), InputHelper.text("Alasan rujukan"), InputHelper.text("Tujuan rujukan"), null);
            crud.insert(entity);
            ConsoleUI.success("Data rujukan berhasil disimpan.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<Rujukan> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (Rujukan entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdRujukan()), String.valueOf(entity.getIdPasien()), safe(entity.getAlasanRujukan()), safe(entity.getTujuanRujukan()), safe(entity.getTanggalRujukan())});
            }
            ConsoleUI.printTable("Data Rujukan", new String[]{"ID", "ID pasien", "Alasan rujukan", "Tujuan rujukan", "Tanggal Rujukan"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            Rujukan entity = new Rujukan(id, InputHelper.integer("ID pasien"), InputHelper.text("Alasan rujukan"), InputHelper.text("Tujuan rujukan"), InputHelper.date("Tanggal Rujukan"));
            crud.update(entity);
            ConsoleUI.success("Data rujukan berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data rujukan berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}