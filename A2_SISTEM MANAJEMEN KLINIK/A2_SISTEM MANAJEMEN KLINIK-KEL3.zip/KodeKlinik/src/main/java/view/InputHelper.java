package view;

import java.util.Locale;
import java.util.Scanner;

public final class InputHelper {
    private static final Scanner SCANNER = new Scanner(System.in);

    private InputHelper() {
    }

    public static String text(String prompt) {
        while (true) {
            System.out.print(prompt + ": ");
            String value = SCANNER.nextLine().trim();
            if (!value.isBlank()) {
                return value;
            }
            ConsoleUI.warning("Input tidak boleh kosong.");
        }
    }

    public static String optionalText(String prompt) {
        System.out.print(prompt + ": ");
        String value = SCANNER.nextLine().trim();
        return value.isBlank() ? null : value;
    }

    public static int integer(String prompt) {
        while (true) {
            System.out.print(prompt + ": ");
            String value = SCANNER.nextLine().trim();
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException e) {
                ConsoleUI.warning("Masukkan angka yang valid.");
            }
        }
    }

    public static double decimal(String prompt) {
        while (true) {
            System.out.print(prompt + ": ");
            String value = SCANNER.nextLine().trim().replace(',', '.');
            try {
                return Double.parseDouble(value);
            } catch (NumberFormatException e) {
                ConsoleUI.warning("Masukkan angka desimal yang valid.");
            }
        }
    }

    public static String date(String prompt) {
        while (true) {
            System.out.print(prompt + " [YYYY-MM-DD]: ");
            String value = SCANNER.nextLine().trim();
            if (value.isBlank()) {
                ConsoleUI.warning("Tanggal tidak boleh kosong.");
                continue;
            }
            if (isDate(value)) {
                return value;
            }
            ConsoleUI.warning("Format tanggal tidak valid.");
        }
    }

    public static String optionalDate(String prompt) {
        while (true) {
            System.out.print(prompt + " [YYYY-MM-DD, kosong jika belum]: ");
            String value = SCANNER.nextLine().trim();
            if (value.isBlank()) {
                return null;
            }
            if (isDate(value)) {
                return value;
            }
            ConsoleUI.warning("Format tanggal tidak valid.");
        }
    }

    public static int menuChoice(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt + ": ");
            String value = SCANNER.nextLine().trim();
            try {
                int choice = Integer.parseInt(value);
                if (choice >= min && choice <= max) {
                    return choice;
                }
            } catch (NumberFormatException ignored) {
            }
            ConsoleUI.warning("Pilih angka antara " + min + " dan " + max + ".");
        }
    }

    public static void pause() {
        System.out.print("Tekan Enter untuk lanjut...");
        SCANNER.nextLine();
    }

    private static boolean isDate(String value) {
        try {
            java.time.LocalDate.parse(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
