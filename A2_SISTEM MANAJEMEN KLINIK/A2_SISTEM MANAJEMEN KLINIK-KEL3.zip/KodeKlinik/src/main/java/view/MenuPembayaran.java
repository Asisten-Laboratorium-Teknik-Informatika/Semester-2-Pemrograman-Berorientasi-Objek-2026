package view;

import crud.*;
import transaksi.Pembayaran;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuPembayaran {
    private final PembayaranM crud = new PembayaranM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu Pembayaran");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            Pembayaran entity = new Pembayaran(0, InputHelper.integer("ID pendaftaran"), 0.0, null, InputHelper.text("Metode pembayaran (tunai/transfer/debit/qris)"), null);
            crud.insert(entity);
            ConsoleUI.success("Data pembayaran berhasil diproses.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<Pembayaran> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (Pembayaran entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdPembayaran()), String.valueOf(entity.getIdPendaftaran()), String.valueOf(entity.getTotalBayar()), safe(entity.getTanggalPembayaran()), safe(entity.getMetodePembayaran()), safe(entity.getStatusPembayaran())});
            }
            ConsoleUI.printTable("Data Pembayaran", new String[]{"ID", "ID pendaftaran", "Total Bayar", "Tanggal Pembayaran", "Metode pembayaran (tunai/transfer/debit/qris)", "Status Pembayaran"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            Pembayaran entity = new Pembayaran(id, InputHelper.integer("ID pendaftaran"), InputHelper.decimal("Total bayar"), InputHelper.date("Tanggal pembayaran (YYYY-MM-DD)"), InputHelper.text("Metode pembayaran (tunai/transfer/debit/qris)"), InputHelper.text("Status pembayaran (belum_bayar/lunas/batal)"));
            crud.update(entity);
            ConsoleUI.success("Data pembayaran berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data pembayaran berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}