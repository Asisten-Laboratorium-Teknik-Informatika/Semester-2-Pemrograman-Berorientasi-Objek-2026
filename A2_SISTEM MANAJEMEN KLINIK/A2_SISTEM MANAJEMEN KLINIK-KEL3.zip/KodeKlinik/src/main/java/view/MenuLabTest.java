package view;

import crud.*;
import transaksi.LabTest;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuLabTest {
    private final LabTestM crud = new LabTestM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu LabTest");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            LabTest entity = new LabTest(0, InputHelper.integer("ID pemeriksaan"), InputHelper.text("Jenis test"), InputHelper.text("Hasil test"), null);
            crud.insert(entity);
            ConsoleUI.success("Data labtest berhasil disimpan.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<LabTest> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (LabTest entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdLabTest()), String.valueOf(entity.getIdPemeriksaan()), safe(entity.getJenisTest()), safe(entity.getHasilTest()), safe(entity.getTanggalTest())});
            }
            ConsoleUI.printTable("Data LabTest", new String[]{"ID", "ID pemeriksaan", "Jenis test", "Hasil test", "Tanggal Test"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            LabTest entity = new LabTest(id, InputHelper.integer("ID pemeriksaan"), InputHelper.text("Jenis test"), InputHelper.text("Hasil test"), InputHelper.date("Tanggal Test"));
            crud.update(entity);
            ConsoleUI.success("Data labtest berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data labtest berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}