package view;

import crud.*;
import transaksi.Resep;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuResep {
    private final ResepM crud = new ResepM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu Resep");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            Resep entity = new Resep(0, InputHelper.integer("ID pemeriksaan"), null);
            crud.insert(entity);
            ConsoleUI.success("Data resep berhasil disimpan.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<Resep> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (Resep entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdResep()), String.valueOf(entity.getIdPemeriksaan()), safe(entity.getTanggalResep())});
            }
            ConsoleUI.printTable("Data Resep", new String[]{"ID", "ID pemeriksaan", "Tanggal Resep"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            Resep entity = new Resep(id, InputHelper.integer("ID pemeriksaan"), InputHelper.date("Tanggal Resep"));
            crud.update(entity);
            ConsoleUI.success("Data resep berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data resep berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}