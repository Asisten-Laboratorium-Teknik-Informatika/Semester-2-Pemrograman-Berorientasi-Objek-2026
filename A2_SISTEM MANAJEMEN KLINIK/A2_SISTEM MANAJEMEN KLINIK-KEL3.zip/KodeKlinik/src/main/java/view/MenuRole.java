package view;

import crud.*;
import model.Role;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuRole {
    private final RoleM crud = new RoleM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu Role");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            Role entity = new Role(0, InputHelper.text("Nama role"));
            crud.insert(entity);
            ConsoleUI.success("Data role berhasil disimpan.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<Role> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (Role entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdRole()), safe(entity.getNamaRole())});
            }
            ConsoleUI.printTable("Data Role", new String[]{"ID", "Nama role"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            Role entity = new Role(id, InputHelper.text("Nama role"));
            crud.update(entity);
            ConsoleUI.success("Data role berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data role berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}