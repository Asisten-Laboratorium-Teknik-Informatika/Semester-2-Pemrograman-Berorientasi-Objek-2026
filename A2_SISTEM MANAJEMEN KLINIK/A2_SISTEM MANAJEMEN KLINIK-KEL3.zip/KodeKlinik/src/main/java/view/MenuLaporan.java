package view;

import db.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuLaporan {
    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu Laporan");
            ConsoleUI.info("1. Pendaftaran lengkap");
            ConsoleUI.info("2. Pemeriksaan lengkap");
            ConsoleUI.info("3. Detail tindakan lengkap");
            ConsoleUI.info("4. Detail resep lengkap");
            ConsoleUI.info("5. Tagihan pendaftaran");
            ConsoleUI.info("6. Kunjungan poli");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 6);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> showPendaftaran();
                case 2 -> showPemeriksaan();
                case 3 -> showDetailTindakan();
                case 4 -> showDetailResep();
                case 5 -> showTagihan();
                case 6 -> showKunjunganPoli();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void showPendaftaran() {
        try {
            showView("SELECT * FROM v_pendaftaran_lengkap ORDER BY id_pendaftaran", "Pendaftaran lengkap", new String[]{"id_pendaftaran", "tanggal_pendaftaran", "id_pasien", "nama_pasien", "id_poli", "nama_poli"}, new String[]{"ID", "Tanggal", "ID Pasien", "Nama Pasien", "ID Poli", "Nama Poli"});
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showPemeriksaan() {
        try {
            showView("SELECT * FROM v_pemeriksaan_lengkap ORDER BY id_pemeriksaan", "Pemeriksaan lengkap", new String[]{"id_pemeriksaan", "tanggal_pemeriksaan", "id_pendaftaran", "nama_pasien", "nama_dokter", "nama_poli", "berat_badan", "tekanan_darah", "diagnosa"}, new String[]{"ID", "Tanggal", "ID Pendaftaran", "Nama Pasien", "Nama Dokter", "Nama Poli", "Berat Badan", "Tekanan Darah", "Diagnosa"});
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showDetailTindakan() {
        try {
            showView("SELECT * FROM v_detail_tindakan_lengkap ORDER BY id_detail_tindakan", "Detail tindakan lengkap", new String[]{"id_detail_tindakan", "id_pemeriksaan", "nama_tindakan", "jumlah", "biaya_tindakan", "sub_total"}, new String[]{"ID", "ID Pemeriksaan", "Nama Tindakan", "Jumlah", "Biaya", "Sub Total"});
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showDetailResep() {
        try {
            showView("SELECT * FROM v_detail_resep_lengkap ORDER BY id_detail_resep", "Detail resep lengkap", new String[]{"id_detail_resep", "id_resep", "nama_obat", "jenis_obat", "jumlah_obat", "dosis", "harga_obat", "total_obat"}, new String[]{"ID", "ID Resep", "Nama Obat", "Jenis", "Jumlah", "Dosis", "Harga", "Total"});
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showTagihan() {
        try {
            showView("SELECT * FROM v_tagihan_pendaftaran ORDER BY id_pendaftaran", "Tagihan pendaftaran", new String[]{"id_pendaftaran", "nama_pasien", "nama_poli", "tanggal_pendaftaran", "total_tindakan", "total_obat", "total_bayar", "status_pembayaran"}, new String[]{"ID", "Nama Pasien", "Nama Poli", "Tanggal", "Total Tindakan", "Total Obat", "Total Bayar", "Status"});
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showKunjunganPoli() {
        try {
            showView("SELECT * FROM v_laporan_kunjungan_poli ORDER BY id_poli", "Kunjungan poli", new String[]{"id_poli", "nama_poli", "total_kunjungan"}, new String[]{"ID Poli", "Nama Poli", "Total Kunjungan"});
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showView(String sql, String title, String[] columns, String[] headers) throws SQLException {
        List<String[]> rows = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String[] row = new String[columns.length];
                for (int i = 0; i < columns.length; i++) {
                    Object value = rs.getObject(columns[i]);
                    row[i] = value == null ? "-" : String.valueOf(value);
                }
                rows.add(row);
            }
        }
        ConsoleUI.printTable(title, headers, rows);
    }
}