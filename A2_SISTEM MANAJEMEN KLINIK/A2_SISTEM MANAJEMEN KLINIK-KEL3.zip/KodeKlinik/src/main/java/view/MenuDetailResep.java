package view;

import crud.*;
import detail.DetailResep;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuDetailResep {
    private final DetailResepM crud = new DetailResepM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu DetailResep");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            DetailResep entity = new DetailResep(0, InputHelper.integer("ID resep"), InputHelper.integer("ID obat"), InputHelper.integer("Jumlah obat"), InputHelper.text("Dosis"));
            crud.insert(entity);
            ConsoleUI.success("Data detailresep berhasil disimpan.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<DetailResep> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (DetailResep entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdDetailResep()), String.valueOf(entity.getIdResep()), String.valueOf(entity.getIdObat()), String.valueOf(entity.getJumlahObat()), safe(entity.getDosis())});
            }
            ConsoleUI.printTable("Data DetailResep", new String[]{"ID", "ID resep", "ID obat", "Jumlah obat", "Dosis"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            DetailResep entity = new DetailResep(id, InputHelper.integer("ID resep"), InputHelper.integer("ID obat"), InputHelper.integer("Jumlah obat"), InputHelper.text("Dosis"));
            crud.update(entity);
            ConsoleUI.success("Data detailresep berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data detailresep berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}