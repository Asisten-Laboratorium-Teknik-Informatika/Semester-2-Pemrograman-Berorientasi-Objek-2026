package view;

import crud.*;
import transaksi.Pendaftaran;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuPendaftaran {
    private final PendaftaranM crud = new PendaftaranM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu Pendaftaran");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            Pendaftaran entity = new Pendaftaran(0, InputHelper.integer("ID pasien"), InputHelper.integer("ID poli"), null);
            crud.insert(entity);
            ConsoleUI.success("Data pendaftaran berhasil disimpan.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<Pendaftaran> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (Pendaftaran entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdPendaftaran()), String.valueOf(entity.getIdPasien()), String.valueOf(entity.getIdPoli()), safe(entity.getTanggalPendaftaran())});
            }
            ConsoleUI.printTable("Data Pendaftaran", new String[]{"ID", "ID pasien", "ID poli", "Tanggal Pendaftaran"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            Pendaftaran entity = new Pendaftaran(id, InputHelper.integer("ID pasien"), InputHelper.integer("ID poli"), InputHelper.date("Tanggal Pendaftaran"));
            crud.update(entity);
            ConsoleUI.success("Data pendaftaran berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data pendaftaran berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}