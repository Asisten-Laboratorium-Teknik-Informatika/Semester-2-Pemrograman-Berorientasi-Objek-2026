package view;

import crud.*;
import detail.DetailTindakan;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuDetailTindakan {
    private final DetailTindakanM crud = new DetailTindakanM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu DetailTindakan");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            DetailTindakan entity = new DetailTindakan(0, InputHelper.integer("ID pemeriksaan"), InputHelper.integer("ID tindakan"), InputHelper.integer("Jumlah"), 0.0);
            crud.insert(entity);
            ConsoleUI.success("Data detailtindakan berhasil disimpan.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<DetailTindakan> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (DetailTindakan entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdDetailTindakan()), String.valueOf(entity.getIdPemeriksaan()), String.valueOf(entity.getIdTindakan()), String.valueOf(entity.getJumlah()), String.valueOf(entity.getSubTotal())});
            }
            ConsoleUI.printTable("Data DetailTindakan", new String[]{"ID", "ID pemeriksaan", "ID tindakan", "Jumlah", "Sub Total"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            DetailTindakan entity = new DetailTindakan(id, InputHelper.integer("ID pemeriksaan"), InputHelper.integer("ID tindakan"), InputHelper.integer("Jumlah"), 0.0);
            crud.update(entity);
            ConsoleUI.success("Data detailtindakan berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data detailtindakan berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}