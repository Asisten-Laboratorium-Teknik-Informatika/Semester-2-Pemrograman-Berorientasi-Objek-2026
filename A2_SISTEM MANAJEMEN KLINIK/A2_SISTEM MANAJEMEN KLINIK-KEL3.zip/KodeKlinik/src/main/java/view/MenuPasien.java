package view;

import crud.*;
import model.Pasien;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuPasien {
    private final PasienM crud = new PasienM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu Pasien");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            Pasien entity = new Pasien(0, InputHelper.text("Nama pasien"), InputHelper.text("Jenis kelamin (L/P)"), InputHelper.date("Tanggal lahir (YYYY-MM-DD)"), InputHelper.text("Alamat"), InputHelper.text("No HP"), InputHelper.text("Golongan darah"));
            crud.insert(entity);
            ConsoleUI.success("Data pasien berhasil disimpan.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<Pasien> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (Pasien entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdPasien()), safe(entity.getNama()), safe(entity.getJenisKelamin()), safe(entity.getTanggalLahir()), safe(entity.getAlamat()), safe(entity.getNoHp()), safe(entity.getGolonganDarah())});
            }
            ConsoleUI.printTable("Data Pasien", new String[]{"ID", "Nama pasien", "Jenis kelamin (L/P)", "Tanggal lahir (YYYY-MM-DD)", "Alamat", "No HP", "Golongan darah"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            Pasien entity = new Pasien(id, InputHelper.text("Nama pasien"), InputHelper.text("Jenis kelamin (L/P)"), InputHelper.date("Tanggal lahir (YYYY-MM-DD)"), InputHelper.text("Alamat"), InputHelper.text("No HP"), InputHelper.text("Golongan darah"));
            crud.update(entity);
            ConsoleUI.success("Data pasien berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data pasien berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}