package view;

import crud.*;
import transaksi.Pemeriksaan;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuPemeriksaan {
    private final PemeriksaanM crud = new PemeriksaanM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu Pemeriksaan");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            Pemeriksaan entity = new Pemeriksaan(0, InputHelper.integer("ID pendaftaran"), InputHelper.integer("ID dokter"), null, InputHelper.decimal("Berat badan"), InputHelper.text("Tekanan darah"), InputHelper.text("Diagnosa"));
            crud.insert(entity);
            ConsoleUI.success("Data pemeriksaan berhasil disimpan.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<Pemeriksaan> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (Pemeriksaan entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdPemeriksaan()), String.valueOf(entity.getIdPendaftaran()), String.valueOf(entity.getIdDokter()), safe(entity.getTanggalPemeriksaan()), String.valueOf(entity.getBeratBadan()), safe(entity.getTekananDarah()), safe(entity.getDiagnosa())});
            }
            ConsoleUI.printTable("Data Pemeriksaan", new String[]{"ID", "ID pendaftaran", "ID dokter", "Tanggal Pemeriksaan", "Berat badan", "Tekanan darah", "Diagnosa"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            Pemeriksaan entity = new Pemeriksaan(id, InputHelper.integer("ID pendaftaran"), InputHelper.integer("ID dokter"), InputHelper.date("Tanggal Pemeriksaan"), InputHelper.decimal("Berat badan"), InputHelper.text("Tekanan darah"), InputHelper.text("Diagnosa"));
            crud.update(entity);
            ConsoleUI.success("Data pemeriksaan berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data pemeriksaan berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}