package view;

import crud.*;
import model.Pegawai;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MenuPegawai {
    private final PegawaiM crud = new PegawaiM();

    public void displayMenu() {
        while (true) {
            ConsoleUI.banner("Menu Pegawai");
            ConsoleUI.info("1. Tambah data");
            ConsoleUI.info("2. Lihat data");
            ConsoleUI.info("3. Ubah data");
            ConsoleUI.info("4. Hapus data");
            ConsoleUI.info("0. Kembali");
            int choice = InputHelper.menuChoice("Pilih menu", 0, 4);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> addData();
                case 2 -> showData();
                case 3 -> updateData();
                case 4 -> deleteData();
                default -> ConsoleUI.warning("Pilihan tidak dikenal.");
            }
        }
    }

    private void addData() {
        try {
            Pegawai entity = new Pegawai(0, InputHelper.text("Nama pegawai"), InputHelper.text("Alamat"), InputHelper.text("No HP"), InputHelper.text("Email"), InputHelper.text("Username"), InputHelper.text("Password"), InputHelper.integer("ID role"));
            crud.insert(entity);
            ConsoleUI.success("Data pegawai berhasil disimpan.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void showData() {
        try {
            List<Pegawai> data = crud.findAll();
            if (data.isEmpty()) {
                ConsoleUI.info("Belum ada data.");
                InputHelper.pause();
                return;
            }
            List<String[]> rows = new ArrayList<>();
            for (Pegawai entity : data) {
                rows.add(new String[]{String.valueOf(entity.getIdPegawai()), safe(entity.getNamaPegawai()), safe(entity.getAlamat()), safe(entity.getNoHp()), safe(entity.getEmail()), safe(entity.getUsername()), safe(entity.getPassword()), String.valueOf(entity.getIdRole())});
            }
            ConsoleUI.printTable("Data Pegawai", new String[]{"ID", "Nama pegawai", "Alamat", "No HP", "Email", "Username", "Password", "ID role"}, rows);
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void updateData() {
        try {
            int id = InputHelper.integer("ID yang akan diubah");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            Pegawai entity = new Pegawai(id, InputHelper.text("Nama pegawai"), InputHelper.text("Alamat"), InputHelper.text("No HP"), InputHelper.text("Email"), InputHelper.text("Username"), InputHelper.text("Password"), InputHelper.integer("ID role"));
            crud.update(entity);
            ConsoleUI.success("Data pegawai berhasil diperbarui.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private void deleteData() {
        try {
            int id = InputHelper.integer("ID yang akan dihapus");
            if (crud.findById(id) == null) {
                ConsoleUI.warning("Data tidak ditemukan.");
                InputHelper.pause();
                return;
            }
            crud.deleteById(id);
            ConsoleUI.success("Data pegawai berhasil dihapus.");
        } catch (SQLException e) {
            ConsoleUI.error(e.getMessage());
        }
        InputHelper.pause();
    }

    private String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}