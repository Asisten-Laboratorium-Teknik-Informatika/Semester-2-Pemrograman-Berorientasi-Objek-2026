package view;

import java.util.ArrayList;
import java.util.List;

public final class ConsoleUI {
    private ConsoleUI() {
    }

    public static void banner(String title) {
        System.out.println();
        System.out.println("==================================================");
        System.out.println(center(title, 50));
        System.out.println("==================================================");
    }

    public static void section(String title) {
        System.out.println();
        System.out.println("---- " + title + " ----");
    }

    public static void success(String message) {
        System.out.println("[OK] " + message);
    }

    public static void info(String message) {
        System.out.println("[INFO] " + message);
    }

    public static void warning(String message) {
        System.out.println("[Peringatan] " + message);
    }

    public static void error(String message) {
        System.out.println("[Gagal] " + message);
    }

    public static void blank() {
        System.out.println();
    }

    public static void divider() {
        System.out.println("--------------------------------------------------");
    }

    public static void printTable(String title, String[] headers, List<String[]> rows) {
        section(title);
        if (rows == null || rows.isEmpty()) {
            System.out.println("Tidak ada data.");
            return;
        }

        int columns = headers.length;
        int[] widths = new int[columns];
        for (int i = 0; i < columns; i++) {
            widths[i] = headers[i].length();
        }
        for (String[] row : rows) {
            for (int i = 0; i < columns && i < row.length; i++) {
                int size = row[i] == null ? 4 : row[i].length();
                if (size > widths[i]) {
                    widths[i] = size;
                }
            }
        }

        System.out.println(buildLine(widths));
        System.out.println(buildRow(headers, widths));
        System.out.println(buildLine(widths));
        for (String[] row : rows) {
            String[] copy = new String[columns];
            for (int i = 0; i < columns; i++) {
                copy[i] = i < row.length ? row[i] : "";
            }
            System.out.println(buildRow(copy, widths));
        }
        System.out.println(buildLine(widths));
    }

    public static void printSummary(List<String[]> rows) {
        if (rows == null || rows.isEmpty()) {
            return;
        }
        int maxLeft = 0;
        for (String[] row : rows) {
            if (row.length > 0 && row[0] != null && row[0].length() > maxLeft) {
                maxLeft = row[0].length();
            }
        }
        for (String[] row : rows) {
            String left = row.length > 0 && row[0] != null ? row[0] : "";
            String right = row.length > 1 && row[1] != null ? row[1] : "";
            System.out.println(padRight(left, maxLeft) + " : " + right);
        }
    }

    private static String buildLine(int[] widths) {
        StringBuilder sb = new StringBuilder();
        sb.append('+');
        for (int width : widths) {
            sb.append("-".repeat(Math.max(width + 2, 3)));
            sb.append('+');
        }
        return sb.toString();
    }

    private static String buildRow(String[] row, int[] widths) {
        StringBuilder sb = new StringBuilder();
        sb.append('|');
        for (int i = 0; i < widths.length; i++) {
            String value = row[i] == null ? "" : row[i];
            sb.append(' ').append(padRight(value, widths[i])).append(' ').append('|');
        }
        return sb.toString();
    }

    private static String padRight(String value, int width) {
        if (value.length() >= width) {
            return value;
        }
        return value + " ".repeat(width - value.length());
    }

    private static String center(String value, int width) {
        if (value.length() >= width) {
            return value;
        }
        int left = (width - value.length()) / 2;
        int right = width - value.length() - left;
        return " ".repeat(left) + value + " ".repeat(right);
    }
}
