package crud;

import db.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public abstract class CrudSupport<T> {
    protected Connection connection() throws SQLException {
        return DBConnection.getConnection();
    }

    protected int execute(String sql, Object... params) throws SQLException {
        try (Connection conn = connection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            bind(stmt, params);
            return stmt.executeUpdate();
        }
    }

    protected long executeInsert(String sql, Object... params) throws SQLException {
        try (Connection conn = connection(); PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(stmt, params);
            stmt.executeUpdate();
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getLong(1);
                }
            }
            return -1L;
        }
    }

    protected <R> List<R> query(String sql, RowMapper<R> mapper, Object... params) throws SQLException {
        try (Connection conn = connection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            bind(stmt, params);
            try (ResultSet rs = stmt.executeQuery()) {
                List<R> rows = new ArrayList<>();
                while (rs.next()) {
                    rows.add(mapper.map(rs));
                }
                return rows;
            }
        }
    }

    protected <R> R queryOne(String sql, RowMapper<R> mapper, Object... params) throws SQLException {
        List<R> rows = query(sql, mapper, params);
        return rows.isEmpty() ? null : rows.get(0);
    }

    protected int countRows(String table) throws SQLException {
        try (Connection conn = connection(); PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM " + table); ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
            return 0;
        }
    }

    protected String toDateString(java.sql.Date date) {
        return date == null ? null : date.toString();
    }

    protected java.sql.Date toSqlDate(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return java.sql.Date.valueOf(value.trim());
    }

    private void bind(PreparedStatement stmt, Object[] params) throws SQLException {
        for (int i = 0; i < params.length; i++) {
            Object value = params[i];
            int index = i + 1;
            if (value == null) {
                stmt.setObject(index, null);
            } else if (value instanceof Integer) {
                stmt.setInt(index, (Integer) value);
            } else if (value instanceof Long) {
                stmt.setLong(index, (Long) value);
            } else if (value instanceof Double) {
                stmt.setDouble(index, (Double) value);
            } else if (value instanceof Float) {
                stmt.setFloat(index, (Float) value);
            } else if (value instanceof java.math.BigDecimal) {
                stmt.setBigDecimal(index, (java.math.BigDecimal) value);
            } else if (value instanceof Boolean) {
                stmt.setBoolean(index, (Boolean) value);
            } else if (value instanceof java.sql.Date) {
                stmt.setDate(index, (java.sql.Date) value);
            } else {
                stmt.setObject(index, value);
            }
        }
    }
}
