package crud;

import java.sql.SQLException;
import java.util.List;
import model.Pasien;

public class PasienM extends CrudSupport<Pasien> {
    private static final String SELECT_ALL_SQL = "SELECT id_pasien, nama, jenis_kelamin, tanggal_lahir, alamat, no_hp, golongan_darah FROM pasien ORDER BY id_pasien";
    private static final String SELECT_BY_ID_SQL = "SELECT id_pasien, nama, jenis_kelamin, tanggal_lahir, alamat, no_hp, golongan_darah FROM pasien WHERE id_pasien = ?";
    private static final String UPDATE_SQL = "UPDATE pasien SET nama = ?, jenis_kelamin = ?, tanggal_lahir = ?, alamat = ?, no_hp = ?, golongan_darah = ? WHERE id_pasien = ?";
    private static final String DELETE_SQL = "DELETE FROM pasien WHERE id_pasien = ?";

    public List<Pasien> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new Pasien(rs.getInt("id_pasien"), rs.getString("nama"), rs.getString("jenis_kelamin"), toDateString(rs.getDate("tanggal_lahir")), rs.getString("alamat"), rs.getString("no_hp"), rs.getString("golongan_darah")));
    }

    public Pasien findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new Pasien(rs.getInt("id_pasien"), rs.getString("nama"), rs.getString("jenis_kelamin"), toDateString(rs.getDate("tanggal_lahir")), rs.getString("alamat"), rs.getString("no_hp"), rs.getString("golongan_darah")), id);
    }

    public boolean insert(Pasien entity) throws SQLException {
        return execute("INSERT INTO pasien (nama, jenis_kelamin, tanggal_lahir, alamat, no_hp, golongan_darah) VALUES (?, ?, ?, ?, ?, ?)", entity.getNama(), entity.getJenisKelamin(), toSqlDate(entity.getTanggalLahir()), entity.getAlamat(), entity.getNoHp(), entity.getGolonganDarah()) > 0;
    }

    public boolean update(Pasien entity) throws SQLException {
        return execute("UPDATE pasien SET nama = ?, jenis_kelamin = ?, tanggal_lahir = ?, alamat = ?, no_hp = ?, golongan_darah = ? WHERE id_pasien = ?", entity.getNama(), entity.getJenisKelamin(), toSqlDate(entity.getTanggalLahir()), entity.getAlamat(), entity.getNoHp(), entity.getGolonganDarah(), entity.getIdPasien()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM pasien WHERE id_pasien = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("pasien");
    }
}