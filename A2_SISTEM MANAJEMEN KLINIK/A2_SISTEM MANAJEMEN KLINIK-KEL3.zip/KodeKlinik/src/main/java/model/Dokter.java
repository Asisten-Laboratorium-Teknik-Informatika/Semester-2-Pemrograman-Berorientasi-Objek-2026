package model;

public class Dokter {

    private int idDokter;
    private String namaDokter;
    private String spesialis;
    private String noHp;
    private int idPoli;

    public Dokter(int idDokter, String namaDokter, String spesialis, String noHp, int idPoli) {
        this.idDokter = idDokter;
        this.namaDokter = namaDokter;
        this.spesialis = spesialis;
        this.noHp = noHp;
        this.idPoli = idPoli;
    }

    public int getIdDokter() {
        return idDokter;
    }

    public String getNamaDokter() {
        return namaDokter;
    }

    public String getSpesialis() {
        return spesialis;
    }

    public String getNoHp() {
        return noHp;
    }

    public int getIdPoli() {
        return idPoli;
    }

    public void setIdDokter(int idDokter) {
        this.idDokter = idDokter;
    }

    public void setNamaDokter(String namaDokter) {
        this.namaDokter = namaDokter;
    }

    public void setSpesialis(String spesialis) {
        this.spesialis = spesialis;
    }

    public void setNoHp(String noHp) {
        this.noHp = noHp;
    }

    public void setIdPoli(int idPoli) {
        this.idPoli = idPoli;
    }

}