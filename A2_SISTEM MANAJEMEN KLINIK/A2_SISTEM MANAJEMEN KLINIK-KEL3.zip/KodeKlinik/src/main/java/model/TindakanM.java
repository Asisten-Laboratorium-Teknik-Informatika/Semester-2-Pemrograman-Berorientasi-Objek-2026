package crud;

import java.sql.SQLException;
import java.util.List;
import model.Tindakan;

public class TindakanM extends CrudSupport<Tindakan> {
    private static final String SELECT_ALL_SQL = "SELECT id_tindakan, nama_tindakan, biaya_tindakan FROM tindakan ORDER BY id_tindakan";
    private static final String SELECT_BY_ID_SQL = "SELECT id_tindakan, nama_tindakan, biaya_tindakan FROM tindakan WHERE id_tindakan = ?";
    private static final String UPDATE_SQL = "UPDATE tindakan SET nama_tindakan = ?, biaya_tindakan = ? WHERE id_tindakan = ?";
    private static final String DELETE_SQL = "DELETE FROM tindakan WHERE id_tindakan = ?";

    public List<Tindakan> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new Tindakan(rs.getInt("id_tindakan"), rs.getString("nama_tindakan"), rs.getDouble("biaya_tindakan")));
    }

    public Tindakan findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new Tindakan(rs.getInt("id_tindakan"), rs.getString("nama_tindakan"), rs.getDouble("biaya_tindakan")), id);
    }

    public boolean insert(Tindakan entity) throws SQLException {
        return execute("INSERT INTO tindakan (nama_tindakan, biaya_tindakan) VALUES (?, ?)", entity.getNamaTindakan(), entity.getBiayaTindakan()) > 0;
    }

    public boolean update(Tindakan entity) throws SQLException {
        return execute("UPDATE tindakan SET nama_tindakan = ?, biaya_tindakan = ? WHERE id_tindakan = ?", entity.getNamaTindakan(), entity.getBiayaTindakan(), entity.getIdTindakan()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM tindakan WHERE id_tindakan = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("tindakan");
    }
}