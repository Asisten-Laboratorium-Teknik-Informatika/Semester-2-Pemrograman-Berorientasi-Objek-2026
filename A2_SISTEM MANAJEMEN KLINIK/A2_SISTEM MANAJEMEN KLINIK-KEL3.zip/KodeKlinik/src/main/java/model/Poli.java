package model;

public class Poli {

    private int idPoli;
    private String namaPoli;
    private String lokasiPoli;

    public Poli(int idPoli, String namaPoli, String lokasiPoli) {
        this.idPoli = idPoli;
        this.namaPoli = namaPoli;
        this.lokasiPoli = lokasiPoli;
    }

    public int getIdPoli() {
        return idPoli;
    }

    public String getNamaPoli() {
        return namaPoli;
    }

    public String getLokasiPoli() {
        return lokasiPoli;
    }

    public void setIdPoli(int idPoli) {
        this.idPoli = idPoli;
    }

    public void setNamaPoli(String namaPoli) {
        this.namaPoli = namaPoli;
    }

    public void setLokasiPoli(String lokasiPoli) {
        this.lokasiPoli = lokasiPoli;
    }

}