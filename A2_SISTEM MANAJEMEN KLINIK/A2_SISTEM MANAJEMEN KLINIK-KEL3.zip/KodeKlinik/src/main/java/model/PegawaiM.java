package crud;

import java.sql.SQLException;
import java.util.List;
import model.Pegawai;

public class PegawaiM extends CrudSupport<Pegawai> {
    private static final String SELECT_ALL_SQL = "SELECT id_pegawai, nama_pegawai, alamat, no_hp, email, username, password, id_role FROM pegawai ORDER BY id_pegawai";
    private static final String SELECT_BY_ID_SQL = "SELECT id_pegawai, nama_pegawai, alamat, no_hp, email, username, password, id_role FROM pegawai WHERE id_pegawai = ?";
    private static final String UPDATE_SQL = "UPDATE pegawai SET nama_pegawai = ?, alamat = ?, no_hp = ?, email = ?, username = ?, password = ?, id_role = ? WHERE id_pegawai = ?";
    private static final String DELETE_SQL = "DELETE FROM pegawai WHERE id_pegawai = ?";

    public List<Pegawai> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new Pegawai(rs.getInt("id_pegawai"), rs.getString("nama_pegawai"), rs.getString("alamat"), rs.getString("no_hp"), rs.getString("email"), rs.getString("username"), rs.getString("password"), rs.getInt("id_role")));
    }

    public Pegawai findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new Pegawai(rs.getInt("id_pegawai"), rs.getString("nama_pegawai"), rs.getString("alamat"), rs.getString("no_hp"), rs.getString("email"), rs.getString("username"), rs.getString("password"), rs.getInt("id_role")), id);
    }

    public boolean insert(Pegawai entity) throws SQLException {
        return execute("INSERT INTO pegawai (nama_pegawai, alamat, no_hp, email, username, password, id_role) VALUES (?, ?, ?, ?, ?, ?, ?)", entity.getNamaPegawai(), entity.getAlamat(), entity.getNoHp(), entity.getEmail(), entity.getUsername(), entity.getPassword(), entity.getIdRole()) > 0;
    }

    public boolean update(Pegawai entity) throws SQLException {
        return execute("UPDATE pegawai SET nama_pegawai = ?, alamat = ?, no_hp = ?, email = ?, username = ?, password = ?, id_role = ? WHERE id_pegawai = ?", entity.getNamaPegawai(), entity.getAlamat(), entity.getNoHp(), entity.getEmail(), entity.getUsername(), entity.getPassword(), entity.getIdRole(), entity.getIdPegawai()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM pegawai WHERE id_pegawai = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("pegawai");
    }
}