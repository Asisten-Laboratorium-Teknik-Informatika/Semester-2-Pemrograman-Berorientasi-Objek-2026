package crud;

import java.sql.SQLException;
import java.util.List;
import model.Dokter;

public class DokterM extends CrudSupport<Dokter> {
    private static final String SELECT_ALL_SQL = "SELECT id_dokter, nama_dokter, spesialis, no_hp, id_poli FROM dokter ORDER BY id_dokter";
    private static final String SELECT_BY_ID_SQL = "SELECT id_dokter, nama_dokter, spesialis, no_hp, id_poli FROM dokter WHERE id_dokter = ?";
    private static final String UPDATE_SQL = "UPDATE dokter SET nama_dokter = ?, spesialis = ?, no_hp = ?, id_poli = ? WHERE id_dokter = ?";
    private static final String DELETE_SQL = "DELETE FROM dokter WHERE id_dokter = ?";

    public List<Dokter> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new Dokter(rs.getInt("id_dokter"), rs.getString("nama_dokter"), rs.getString("spesialis"), rs.getString("no_hp"), rs.getInt("id_poli")));
    }

    public Dokter findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new Dokter(rs.getInt("id_dokter"), rs.getString("nama_dokter"), rs.getString("spesialis"), rs.getString("no_hp"), rs.getInt("id_poli")), id);
    }

    public boolean insert(Dokter entity) throws SQLException {
        return execute("INSERT INTO dokter (nama_dokter, spesialis, no_hp, id_poli) VALUES (?, ?, ?, ?)", entity.getNamaDokter(), entity.getSpesialis(), entity.getNoHp(), entity.getIdPoli()) > 0;
    }

    public boolean update(Dokter entity) throws SQLException {
        return execute("UPDATE dokter SET nama_dokter = ?, spesialis = ?, no_hp = ?, id_poli = ? WHERE id_dokter = ?", entity.getNamaDokter(), entity.getSpesialis(), entity.getNoHp(), entity.getIdPoli(), entity.getIdDokter()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM dokter WHERE id_dokter = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("dokter");
    }
}