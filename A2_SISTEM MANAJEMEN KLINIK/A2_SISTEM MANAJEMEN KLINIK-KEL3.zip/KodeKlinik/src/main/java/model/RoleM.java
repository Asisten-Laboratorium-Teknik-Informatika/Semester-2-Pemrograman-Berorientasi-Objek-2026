package crud;

import java.sql.SQLException;
import java.util.List;
import model.Role;

public class RoleM extends CrudSupport<Role> {
    private static final String SELECT_ALL_SQL = "SELECT id_role, nama_role FROM role ORDER BY id_role";
    private static final String SELECT_BY_ID_SQL = "SELECT id_role, nama_role FROM role WHERE id_role = ?";
    private static final String UPDATE_SQL = "UPDATE role SET nama_role = ? WHERE id_role = ?";
    private static final String DELETE_SQL = "DELETE FROM role WHERE id_role = ?";

    public List<Role> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new Role(rs.getInt("id_role"), rs.getString("nama_role")));
    }

    public Role findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new Role(rs.getInt("id_role"), rs.getString("nama_role")), id);
    }

    public boolean insert(Role entity) throws SQLException {
        return execute("INSERT INTO role (nama_role) VALUES (?)", entity.getNamaRole()) > 0;
    }

    public boolean update(Role entity) throws SQLException {
        return execute("UPDATE role SET nama_role = ? WHERE id_role = ?", entity.getNamaRole(), entity.getIdRole()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM role WHERE id_role = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("role");
    }
}