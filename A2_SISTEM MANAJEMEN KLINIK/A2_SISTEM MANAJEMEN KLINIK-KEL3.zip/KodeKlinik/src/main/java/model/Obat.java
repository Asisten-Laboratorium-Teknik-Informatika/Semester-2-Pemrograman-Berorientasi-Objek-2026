package model;

public class Obat {

    private int idObat;
    private String namaObat;
    private String jenisObat;
    private double hargaObat;
    private int stok;

    public Obat(int idObat, String namaObat, String jenisObat, double hargaObat, int stok) {
        this.idObat = idObat;
        this.namaObat = namaObat;
        this.jenisObat = jenisObat;
        this.hargaObat = hargaObat;
        this.stok = stok;
    }

    public int getIdObat() {
        return idObat;
    }

    public String getNamaObat() {
        return namaObat;
    }

    public String getJenisObat() {
        return jenisObat;
    }

    public double getHargaObat() {
        return hargaObat;
    }

    public int getStok() {
        return stok;
    }

    public void setIdObat(int idObat) {
        this.idObat = idObat;
    }

    public void setNamaObat(String namaObat) {
        this.namaObat = namaObat;
    }

    public void setJenisObat(String jenisObat) {
        this.jenisObat = jenisObat;
    }

    public void setHargaObat(double hargaObat) {
        this.hargaObat = hargaObat;
    }

    public void setStok(int stok) {
        this.stok = stok;
    }

}