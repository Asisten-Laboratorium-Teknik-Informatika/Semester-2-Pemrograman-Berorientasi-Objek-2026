package crud;

import java.sql.SQLException;
import java.util.List;
import model.Poli;

public class PoliM extends CrudSupport<Poli> {
    private static final String SELECT_ALL_SQL = "SELECT id_poli, nama_poli, lokasi_poli FROM poli ORDER BY id_poli";
    private static final String SELECT_BY_ID_SQL = "SELECT id_poli, nama_poli, lokasi_poli FROM poli WHERE id_poli = ?";
    private static final String UPDATE_SQL = "UPDATE poli SET nama_poli = ?, lokasi_poli = ? WHERE id_poli = ?";
    private static final String DELETE_SQL = "DELETE FROM poli WHERE id_poli = ?";

    public List<Poli> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new Poli(rs.getInt("id_poli"), rs.getString("nama_poli"), rs.getString("lokasi_poli")));
    }

    public Poli findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new Poli(rs.getInt("id_poli"), rs.getString("nama_poli"), rs.getString("lokasi_poli")), id);
    }

    public boolean insert(Poli entity) throws SQLException {
        return execute("INSERT INTO poli (nama_poli, lokasi_poli) VALUES (?, ?)", entity.getNamaPoli(), entity.getLokasiPoli()) > 0;
    }

    public boolean update(Poli entity) throws SQLException {
        return execute("UPDATE poli SET nama_poli = ?, lokasi_poli = ? WHERE id_poli = ?", entity.getNamaPoli(), entity.getLokasiPoli(), entity.getIdPoli()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM poli WHERE id_poli = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("poli");
    }
}