package model;

public class Pegawai {

    private int idPegawai;
    private String namaPegawai;
    private String alamat;
    private String noHp;
    private String email;
    private String username;
    private String password;
    private int idRole;

    public Pegawai(int idPegawai, String namaPegawai, String alamat, String noHp, String email, String username, String password, int idRole) {
        this.idPegawai = idPegawai;
        this.namaPegawai = namaPegawai;
        this.alamat = alamat;
        this.noHp = noHp;
        this.email = email;
        this.username = username;
        this.password = password;
        this.idRole = idRole;
    }

    public int getIdPegawai() {
        return idPegawai;
    }

    public String getNamaPegawai() {
        return namaPegawai;
    }

    public String getAlamat() {
        return alamat;
    }

    public String getNoHp() {
        return noHp;
    }

    public String getEmail() {
        return email;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public int getIdRole() {
        return idRole;
    }

    public void setIdPegawai(int idPegawai) {
        this.idPegawai = idPegawai;
    }

    public void setNamaPegawai(String namaPegawai) {
        this.namaPegawai = namaPegawai;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public void setNoHp(String noHp) {
        this.noHp = noHp;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setIdRole(int idRole) {
        this.idRole = idRole;
    }

}