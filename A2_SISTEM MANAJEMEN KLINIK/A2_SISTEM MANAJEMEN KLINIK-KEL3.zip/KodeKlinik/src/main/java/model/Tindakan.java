package model;

public class Tindakan {

    private int idTindakan;
    private String namaTindakan;
    private double biayaTindakan;

    public Tindakan(int idTindakan, String namaTindakan, double biayaTindakan) {
        this.idTindakan = idTindakan;
        this.namaTindakan = namaTindakan;
        this.biayaTindakan = biayaTindakan;
    }

    public int getIdTindakan() {
        return idTindakan;
    }

    public String getNamaTindakan() {
        return namaTindakan;
    }

    public double getBiayaTindakan() {
        return biayaTindakan;
    }

    public void setIdTindakan(int idTindakan) {
        this.idTindakan = idTindakan;
    }

    public void setNamaTindakan(String namaTindakan) {
        this.namaTindakan = namaTindakan;
    }

    public void setBiayaTindakan(double biayaTindakan) {
        this.biayaTindakan = biayaTindakan;
    }

}