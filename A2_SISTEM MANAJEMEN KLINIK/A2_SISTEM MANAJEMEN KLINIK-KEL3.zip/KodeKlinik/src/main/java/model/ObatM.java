package crud;

import java.sql.SQLException;
import java.util.List;
import model.Obat;

public class ObatM extends CrudSupport<Obat> {
    private static final String SELECT_ALL_SQL = "SELECT id_obat, nama_obat, jenis_obat, harga_obat, stok FROM obat ORDER BY id_obat";
    private static final String SELECT_BY_ID_SQL = "SELECT id_obat, nama_obat, jenis_obat, harga_obat, stok FROM obat WHERE id_obat = ?";
    private static final String UPDATE_SQL = "UPDATE obat SET nama_obat = ?, jenis_obat = ?, harga_obat = ?, stok = ? WHERE id_obat = ?";
    private static final String DELETE_SQL = "DELETE FROM obat WHERE id_obat = ?";

    public List<Obat> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new Obat(rs.getInt("id_obat"), rs.getString("nama_obat"), rs.getString("jenis_obat"), rs.getDouble("harga_obat"), rs.getInt("stok")));
    }

    public Obat findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new Obat(rs.getInt("id_obat"), rs.getString("nama_obat"), rs.getString("jenis_obat"), rs.getDouble("harga_obat"), rs.getInt("stok")), id);
    }

    public boolean insert(Obat entity) throws SQLException {
        return execute("INSERT INTO obat (nama_obat, jenis_obat, harga_obat, stok) VALUES (?, ?, ?, ?)", entity.getNamaObat(), entity.getJenisObat(), entity.getHargaObat(), entity.getStok()) > 0;
    }

    public boolean update(Obat entity) throws SQLException {
        return execute("UPDATE obat SET nama_obat = ?, jenis_obat = ?, harga_obat = ?, stok = ? WHERE id_obat = ?", entity.getNamaObat(), entity.getJenisObat(), entity.getHargaObat(), entity.getStok(), entity.getIdObat()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM obat WHERE id_obat = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("obat");
    }
}