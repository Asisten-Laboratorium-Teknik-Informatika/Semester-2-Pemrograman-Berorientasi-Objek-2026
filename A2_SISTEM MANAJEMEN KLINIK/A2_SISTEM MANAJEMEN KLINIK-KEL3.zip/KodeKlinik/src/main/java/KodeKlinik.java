import view.MenuUtama;

public class KodeKlinik {
    public static void main(String[] args) {
        new MenuUtama().tampilMenuUtama();
    }
}
