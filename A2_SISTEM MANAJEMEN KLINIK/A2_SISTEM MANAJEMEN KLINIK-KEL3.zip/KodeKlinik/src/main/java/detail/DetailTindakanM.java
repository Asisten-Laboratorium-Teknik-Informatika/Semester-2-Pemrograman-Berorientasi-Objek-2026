package crud;

import java.sql.SQLException;
import java.util.List;
import detail.DetailTindakan;

public class DetailTindakanM extends CrudSupport<DetailTindakan> {
    private static final String SELECT_ALL_SQL = "SELECT id_detail_tindakan, id_pemeriksaan, id_tindakan, jumlah, sub_total FROM detail_tindakan ORDER BY id_detail_tindakan";
    private static final String SELECT_BY_ID_SQL = "SELECT id_detail_tindakan, id_pemeriksaan, id_tindakan, jumlah, sub_total FROM detail_tindakan WHERE id_detail_tindakan = ?";
    private static final String UPDATE_SQL = "UPDATE detail_tindakan SET id_pemeriksaan = ?, id_tindakan = ?, jumlah = ? WHERE id_detail_tindakan = ?";
    private static final String DELETE_SQL = "DELETE FROM detail_tindakan WHERE id_detail_tindakan = ?";

    public List<DetailTindakan> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new DetailTindakan(rs.getInt("id_detail_tindakan"), rs.getInt("id_pemeriksaan"), rs.getInt("id_tindakan"), rs.getInt("jumlah"), rs.getDouble("sub_total")));
    }

    public DetailTindakan findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new DetailTindakan(rs.getInt("id_detail_tindakan"), rs.getInt("id_pemeriksaan"), rs.getInt("id_tindakan"), rs.getInt("jumlah"), rs.getDouble("sub_total")), id);
    }

    public boolean insert(DetailTindakan entity) throws SQLException {
        return execute("INSERT INTO detail_tindakan (id_pemeriksaan, id_tindakan, jumlah) VALUES (?, ?, ?)", entity.getIdPemeriksaan(), entity.getIdTindakan(), entity.getJumlah()) > 0;
    }

    public boolean update(DetailTindakan entity) throws SQLException {
        return execute("UPDATE detail_tindakan SET id_pemeriksaan = ?, id_tindakan = ?, jumlah = ? WHERE id_detail_tindakan = ?", entity.getIdPemeriksaan(), entity.getIdTindakan(), entity.getJumlah(), entity.getIdDetailTindakan()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM detail_tindakan WHERE id_detail_tindakan = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("detail_tindakan");
    }
}