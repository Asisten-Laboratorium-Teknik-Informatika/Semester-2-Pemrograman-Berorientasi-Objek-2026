package detail;

public class DetailTindakan {

    private int idDetailTindakan;
    private int idPemeriksaan;
    private int idTindakan;
    private int jumlah;
    private double subTotal;

    public DetailTindakan(int idDetailTindakan, int idPemeriksaan, int idTindakan, int jumlah, double subTotal) {
        this.idDetailTindakan = idDetailTindakan;
        this.idPemeriksaan = idPemeriksaan;
        this.idTindakan = idTindakan;
        this.jumlah = jumlah;
        this.subTotal = subTotal;
    }

    public int getIdDetailTindakan() {
        return idDetailTindakan;
    }

    public int getIdPemeriksaan() {
        return idPemeriksaan;
    }

    public int getIdTindakan() {
        return idTindakan;
    }

    public int getJumlah() {
        return jumlah;
    }

    public double getSubTotal() {
        return subTotal;
    }

    public void setIdDetailTindakan(int idDetailTindakan) {
        this.idDetailTindakan = idDetailTindakan;
    }

    public void setIdPemeriksaan(int idPemeriksaan) {
        this.idPemeriksaan = idPemeriksaan;
    }

    public void setIdTindakan(int idTindakan) {
        this.idTindakan = idTindakan;
    }

    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }

    public void setSubTotal(double subTotal) {
        this.subTotal = subTotal;
    }

}