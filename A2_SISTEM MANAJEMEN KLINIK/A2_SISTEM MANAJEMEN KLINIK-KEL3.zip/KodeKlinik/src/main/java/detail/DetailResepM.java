package crud;

import java.sql.SQLException;
import java.util.List;
import detail.DetailResep;

public class DetailResepM extends CrudSupport<DetailResep> {
    private static final String SELECT_ALL_SQL = "SELECT id_detail_resep, id_resep, id_obat, jumlah_obat, dosis FROM detail_resep ORDER BY id_detail_resep";
    private static final String SELECT_BY_ID_SQL = "SELECT id_detail_resep, id_resep, id_obat, jumlah_obat, dosis FROM detail_resep WHERE id_detail_resep = ?";
    private static final String UPDATE_SQL = "UPDATE detail_resep SET id_resep = ?, id_obat = ?, jumlah_obat = ?, dosis = ? WHERE id_detail_resep = ?";
    private static final String DELETE_SQL = "DELETE FROM detail_resep WHERE id_detail_resep = ?";

    public List<DetailResep> findAll() throws SQLException {
        return query(SELECT_ALL_SQL, rs -> new DetailResep(rs.getInt("id_detail_resep"), rs.getInt("id_resep"), rs.getInt("id_obat"), rs.getInt("jumlah_obat"), rs.getString("dosis")));
    }

    public DetailResep findById(int id) throws SQLException {
        return queryOne(SELECT_BY_ID_SQL, rs -> new DetailResep(rs.getInt("id_detail_resep"), rs.getInt("id_resep"), rs.getInt("id_obat"), rs.getInt("jumlah_obat"), rs.getString("dosis")), id);
    }

    public boolean insert(DetailResep entity) throws SQLException {
        return execute("INSERT INTO detail_resep (id_resep, id_obat, jumlah_obat, dosis) VALUES (?, ?, ?, ?)", entity.getIdResep(), entity.getIdObat(), entity.getJumlahObat(), entity.getDosis()) > 0;
    }

    public boolean update(DetailResep entity) throws SQLException {
        return execute("UPDATE detail_resep SET id_resep = ?, id_obat = ?, jumlah_obat = ?, dosis = ? WHERE id_detail_resep = ?", entity.getIdResep(), entity.getIdObat(), entity.getJumlahObat(), entity.getDosis(), entity.getIdDetailResep()) > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        return execute("DELETE FROM detail_resep WHERE id_detail_resep = ?", id) > 0;
    }

    public int count() throws SQLException {
        return countRows("detail_resep");
    }
}